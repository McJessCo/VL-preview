<?php
/**
 * Title: Case study turinio struktūra
 * Slug: videolab/case-study-sections
 * Categories: videolab
 * Inserter: true
 * Post Types: work
 * Description: Redaguojama darbo aprašo struktūra be nepatvirtintų rezultatų.
 */
?>
<!-- wp:heading -->
<h2 class="wp-block-heading">užduotis.</h2>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>Įrašykite patvirtintą kliento užduotį ir kontekstą.</p>
<!-- /wp:paragraph -->
<!-- wp:heading -->
<h2 class="wp-block-heading">sprendimas.</h2>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>Aprašykite kūrybinį ir gamybinį sprendimą bei patvirtintą apimtį.</p>
<!-- /wp:paragraph -->
<!-- wp:gallery {"linkTo":"none","sizeSlug":"large"} -->
<figure class="wp-block-gallery has-nested-images columns-default is-cropped"></figure>
<!-- /wp:gallery -->
