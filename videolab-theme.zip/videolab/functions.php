<?php
/**
 * Video Lab theme setup.
 *
 * @package VideoLab
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers theme features shared by the front end and editor.
 */
function videolab_theme_setup() {
	add_theme_support( 'editor-styles' );
	add_editor_style( 'style.css' );
	add_theme_support(
		'custom-logo',
		array(
			'height'      => 30,
			'width'       => 148,
			'flex-height' => true,
			'flex-width'  => true,
		)
	);
	add_image_size( 'videolab-card', 960, 720, true );
	add_image_size( 'videolab-hero', 2048, 1143, true );
}
add_action( 'after_setup_theme', 'videolab_theme_setup' );

/**
 * Loads the theme stylesheet.
 */
function videolab_enqueue_assets() {
	$path = get_theme_file_path( 'style.css' );
	wp_enqueue_style(
		'videolab',
		get_stylesheet_uri(),
		array(),
		file_exists( $path ) ? (string) filemtime( $path ) : wp_get_theme()->get( 'Version' )
	);
}
add_action( 'wp_enqueue_scripts', 'videolab_enqueue_assets' );

/**
 * Keeps the pattern inserter focused on project-owned patterns.
 */
function videolab_register_pattern_category() {
	register_block_pattern_category(
		'videolab',
		array( 'label' => __( 'Video Lab', 'videolab' ) )
	);
}
add_action( 'init', 'videolab_register_pattern_category' );

add_filter( 'should_load_remote_block_patterns', '__return_false' );
