<?php
/**
 * Plugin Name: Video Lab Content
 * Description: Video Lab darbų, paslaugų duomenų ir dinaminių turinio blokų modelis.
 * Version: 0.1.8
 * Requires at least: 6.8
 * Tested up to: 7.1
 * Requires PHP: 8.1
 * Author: Video Lab
 * Text Domain: videolab-content
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'VIDEOLAB_CONTENT_VERSION', '0.1.8' );
define( 'VIDEOLAB_CONTENT_DIR', plugin_dir_path( __FILE__ ) );
define( 'VIDEOLAB_CONTENT_URL', plugin_dir_url( __FILE__ ) );

/**
 * Registers the portable work model.
 */
function videolab_content_register_types() {
	register_post_type(
		'work',
		array(
			'labels' => array(
				'name'          => __( 'Darbai', 'videolab-content' ),
				'singular_name' => __( 'Darbas', 'videolab-content' ),
				'add_new_item'  => __( 'Pridėti darbą', 'videolab-content' ),
				'edit_item'     => __( 'Redaguoti darbą', 'videolab-content' ),
				'view_item'     => __( 'Peržiūrėti darbą', 'videolab-content' ),
			),
			'public'       => true,
			'has_archive'  => 'darbai',
			'rewrite'      => array(
				'slug'       => 'darbai',
				'with_front' => false,
			),
			'menu_icon'     => 'dashicons-format-video',
			'show_in_rest'  => true,
			'supports'      => array( 'title', 'editor', 'excerpt', 'thumbnail', 'page-attributes', 'revisions', 'custom-fields' ),
			'template'      => array(
				array( 'core/heading', array( 'content' => 'užduotis.' ) ),
				array( 'core/paragraph', array( 'placeholder' => 'Įrašykite patvirtintą užduotį.' ) ),
				array( 'core/heading', array( 'content' => 'sprendimas.' ) ),
				array( 'core/paragraph', array( 'placeholder' => 'Aprašykite patvirtintą sprendimą ir apimtį.' ) ),
				array( 'core/gallery', array( 'linkTo' => 'none' ) ),
			),
		)
	);

	register_taxonomy(
		'work_service',
		array( 'work' ),
		array(
			'labels' => array(
				'name'          => __( 'Paslaugų kryptys', 'videolab-content' ),
				'singular_name' => __( 'Paslaugų kryptis', 'videolab-content' ),
			),
			'public'            => true,
			'hierarchical'      => true,
			'show_admin_column' => true,
			'show_in_rest'      => true,
			'rewrite'           => array( 'slug' => 'darbu-kryptis' ),
		)
	);
}
add_action( 'init', 'videolab_content_register_types' );

/**
 * Registers sanitized fields used by work and service content.
 */
function videolab_content_register_meta() {
	$work_fields = array(
		'videolab_origin' => array(
			'type'              => 'string',
			'default'           => 'real',
			'sanitize_callback' => 'videolab_content_sanitize_origin',
			'show_in_rest'      => array(
				'schema' => array(
					'type' => 'string',
					'enum' => array( 'real', 'ai_concept' ),
				),
			),
		),
		'videolab_client' => array(
			'type'              => 'string',
			'default'           => '',
			'sanitize_callback' => 'sanitize_text_field',
			'show_in_rest'      => true,
		),
		'videolab_dates' => array(
			'type'              => 'string',
			'default'           => '',
			'sanitize_callback' => 'sanitize_text_field',
			'show_in_rest'      => true,
		),
		'videolab_confirmed_results' => array(
			'type'              => 'string',
			'default'           => '',
			'sanitize_callback' => 'sanitize_textarea_field',
			'show_in_rest'      => true,
		),
		'videolab_video_url' => array(
			'type'              => 'string',
			'default'           => '',
			'sanitize_callback' => 'esc_url_raw',
			'show_in_rest'      => true,
		),
		'videolab_poster_id' => array(
			'type'              => 'integer',
			'default'           => 0,
			'sanitize_callback' => 'absint',
			'show_in_rest'      => true,
		),
	);

	foreach ( $work_fields as $key => $args ) {
		register_post_meta(
			'work',
			$key,
			array_merge(
				$args,
				array(
					'single'        => true,
					'auth_callback' => static function () {
						return current_user_can( 'edit_posts' );
					},
				)
			)
		);
	}

	register_post_meta(
		'work',
		'videolab_gallery_ids',
		array(
			'type'              => 'array',
			'single'            => true,
			'default'           => array(),
			'sanitize_callback' => 'videolab_content_sanitize_ids',
			'show_in_rest'      => array(
				'schema' => array(
					'type'  => 'array',
					'items' => array( 'type' => 'integer' ),
				),
			),
			'auth_callback'     => static function () {
				return current_user_can( 'edit_posts' );
			},
		)
	);

	$service_fields = array(
		'videolab_service_key' => array( 'type' => 'string', 'sanitize_callback' => 'videolab_content_sanitize_service_key' ),
		'videolab_starting_price_eur' => array( 'type' => 'integer', 'sanitize_callback' => 'absint' ),
		'videolab_price_period' => array( 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ),
		'videolab_price_note' => array( 'type' => 'string', 'sanitize_callback' => 'sanitize_textarea_field' ),
		'videolab_scope' => array( 'type' => 'string', 'sanitize_callback' => 'sanitize_textarea_field' ),
		'videolab_exclusions' => array( 'type' => 'string', 'sanitize_callback' => 'sanitize_textarea_field' ),
		'videolab_cta' => array( 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ),
		'videolab_viewer_mode' => array( 'type' => 'string', 'sanitize_callback' => 'videolab_content_sanitize_viewer_mode' ),
	);

	foreach ( $service_fields as $key => $args ) {
		register_post_meta(
			'page',
			$key,
			array_merge(
				$args,
				array(
					'single'        => true,
					'default'       => 'integer' === $args['type'] ? 0 : '',
					'show_in_rest'  => true,
					'auth_callback' => static function () {
						return current_user_can( 'edit_pages' );
					},
				)
			)
		);
	}
}
add_action( 'init', 'videolab_content_register_meta' );

function videolab_content_sanitize_origin( $value ) {
	return in_array( $value, array( 'real', 'ai_concept' ), true ) ? $value : 'real';
}

function videolab_content_sanitize_service_key( $value ) {
	$allowed = array( 'monitoring', 'periodic', 'product' );
	return in_array( $value, $allowed, true ) ? $value : '';
}

function videolab_content_sanitize_viewer_mode( $value ) {
	$allowed = array( 'none', 'poster', 'public_embed', 'private_external' );
	return in_array( $value, $allowed, true ) ? $value : 'none';
}

function videolab_content_sanitize_ids( $value ) {
	if ( is_string( $value ) ) {
		$value = preg_split( '/[\s,]+/', $value );
	}
	return array_values( array_filter( array_map( 'absint', (array) $value ) ) );
}

/**
 * Adds accessible editor controls for the registered fields.
 */
function videolab_content_add_meta_boxes() {
	add_meta_box(
		'videolab-work-details',
		__( 'Video Lab darbo duomenys', 'videolab-content' ),
		'videolab_content_render_work_meta_box',
		'work',
		'normal',
		'high'
	);
	add_meta_box(
		'videolab-service-details',
		__( 'Video Lab paslaugos duomenys', 'videolab-content' ),
		'videolab_content_render_service_meta_box',
		'page',
		'normal',
		'default'
	);
}
add_action( 'add_meta_boxes', 'videolab_content_add_meta_boxes' );

function videolab_content_field( $post_id, $key ) {
	return (string) get_post_meta( $post_id, $key, true );
}

function videolab_content_render_work_meta_box( $post ) {
	wp_nonce_field( 'videolab_content_save_meta', 'videolab_content_nonce' );
	$origin      = videolab_content_field( $post->ID, 'videolab_origin' ) ?: 'real';
	$gallery_ids = implode( ',', (array) get_post_meta( $post->ID, 'videolab_gallery_ids', true ) );
	?>
	<p>
		<label for="videolab_origin"><strong><?php esc_html_e( 'Kilmė', 'videolab-content' ); ?></strong></label><br>
		<select id="videolab_origin" name="videolab_origin">
			<option value="real" <?php selected( $origin, 'real' ); ?>><?php esc_html_e( 'Realus darbas / pateikta medžiaga', 'videolab-content' ); ?></option>
			<option value="ai_concept" <?php selected( $origin, 'ai_concept' ); ?>><?php esc_html_e( 'AI koncepcija', 'videolab-content' ); ?></option>
		</select>
	</p>
	<p>
		<label for="videolab_client"><strong><?php esc_html_e( 'Klientas (nebūtinas, tik patvirtintas)', 'videolab-content' ); ?></strong></label><br>
		<input class="widefat" id="videolab_client" name="videolab_client" value="<?php echo esc_attr( videolab_content_field( $post->ID, 'videolab_client' ) ); ?>">
	</p>
	<p>
		<label for="videolab_dates"><strong><?php esc_html_e( 'Datos (nebūtinos, tik patvirtintos)', 'videolab-content' ); ?></strong></label><br>
		<input class="widefat" id="videolab_dates" name="videolab_dates" value="<?php echo esc_attr( videolab_content_field( $post->ID, 'videolab_dates' ) ); ?>">
	</p>
	<p>
		<label for="videolab_gallery_ids"><strong><?php esc_html_e( 'Galerijos medijos ID', 'videolab-content' ); ?></strong></label><br>
		<input class="widefat" id="videolab_gallery_ids" name="videolab_gallery_ids" value="<?php echo esc_attr( $gallery_ids ); ?>" inputmode="numeric">
		<button class="button videolab-select-gallery" type="button"><?php esc_html_e( 'Pasirinkti mediją', 'videolab-content' ); ?></button>
	</p>
	<p>
		<label for="videolab_confirmed_results"><strong><?php esc_html_e( 'Patvirtinti rezultatai', 'videolab-content' ); ?></strong></label><br>
		<textarea class="widefat" rows="4" id="videolab_confirmed_results" name="videolab_confirmed_results"><?php echo esc_textarea( videolab_content_field( $post->ID, 'videolab_confirmed_results' ) ); ?></textarea>
		<small><?php esc_html_e( 'Palikite tuščią, jei rezultatų teiginiai nepatvirtinti.', 'videolab-content' ); ?></small>
	</p>
	<p>
		<label for="videolab_video_url"><strong><?php esc_html_e( 'Video URL / failas (nebūtinas)', 'videolab-content' ); ?></strong></label><br>
		<input class="widefat" type="url" id="videolab_video_url" name="videolab_video_url" value="<?php echo esc_attr( videolab_content_field( $post->ID, 'videolab_video_url' ) ); ?>">
	</p>
	<?php
}

function videolab_content_render_service_meta_box( $post ) {
	wp_nonce_field( 'videolab_content_save_meta', 'videolab_content_nonce' );
	$key = videolab_content_field( $post->ID, 'videolab_service_key' );
	?>
	<p><?php esc_html_e( 'Užpildykite tik paslaugos puslapiui. Šios kainos dinamiškai rodomos pradžios puslapyje.', 'videolab-content' ); ?></p>
	<p>
		<label for="videolab_service_key"><strong><?php esc_html_e( 'Paslaugos raktas', 'videolab-content' ); ?></strong></label><br>
		<select id="videolab_service_key" name="videolab_service_key">
			<option value=""><?php esc_html_e( 'Ne paslaugos puslapis', 'videolab-content' ); ?></option>
			<option value="monitoring" <?php selected( $key, 'monitoring' ); ?>><?php esc_html_e( 'Projektų stebėsena', 'videolab-content' ); ?></option>
			<option value="periodic" <?php selected( $key, 'periodic' ); ?>><?php esc_html_e( 'Periodinis turinys', 'videolab-content' ); ?></option>
			<option value="product" <?php selected( $key, 'product' ); ?>><?php esc_html_e( 'Produkto video', 'videolab-content' ); ?></option>
		</select>
	</p>
	<p>
		<label for="videolab_starting_price_eur"><strong><?php esc_html_e( 'Pradinė kaina, €', 'videolab-content' ); ?></strong></label><br>
		<input type="number" min="0" step="1" id="videolab_starting_price_eur" name="videolab_starting_price_eur" value="<?php echo esc_attr( videolab_content_field( $post->ID, 'videolab_starting_price_eur' ) ); ?>">
	</p>
	<p>
		<label for="videolab_price_period"><strong><?php esc_html_e( 'Kainos laikotarpis', 'videolab-content' ); ?></strong></label><br>
		<input class="widefat" id="videolab_price_period" name="videolab_price_period" value="<?php echo esc_attr( videolab_content_field( $post->ID, 'videolab_price_period' ) ); ?>" placeholder="/ 12 mėn.">
	</p>
	<p>
		<label for="videolab_price_note"><strong><?php esc_html_e( 'Kainos / apimties pastaba', 'videolab-content' ); ?></strong></label><br>
		<textarea class="widefat" rows="3" id="videolab_price_note" name="videolab_price_note"><?php echo esc_textarea( videolab_content_field( $post->ID, 'videolab_price_note' ) ); ?></textarea>
	</p>
	<p>
		<label for="videolab_scope"><strong><?php esc_html_e( 'Apimtis', 'videolab-content' ); ?></strong></label><br>
		<textarea class="widefat" rows="3" id="videolab_scope" name="videolab_scope"><?php echo esc_textarea( videolab_content_field( $post->ID, 'videolab_scope' ) ); ?></textarea>
	</p>
	<p>
		<label for="videolab_exclusions"><strong><?php esc_html_e( 'Išimtys', 'videolab-content' ); ?></strong></label><br>
		<textarea class="widefat" rows="3" id="videolab_exclusions" name="videolab_exclusions"><?php echo esc_textarea( videolab_content_field( $post->ID, 'videolab_exclusions' ) ); ?></textarea>
	</p>
	<p>
		<label for="videolab_cta"><strong><?php esc_html_e( 'CTA tekstas', 'videolab-content' ); ?></strong></label><br>
		<input class="widefat" id="videolab_cta" name="videolab_cta" value="<?php echo esc_attr( videolab_content_field( $post->ID, 'videolab_cta' ) ); ?>">
	</p>
	<?php if ( 'monitoring' === $key ) : ?>
		<p><strong><?php esc_html_e( 'myTikee projekto rodinys:', 'videolab-content' ); ?></strong> <?php esc_html_e( 'išjungtas (none), kol nėra patvirtinto resurso.', 'videolab-content' ); ?></p>
		<input type="hidden" name="videolab_viewer_mode" value="none">
	<?php endif; ?>
	<?php
}

/**
 * Saves project meta without touching fields absent from the request.
 */
function videolab_content_save_meta( $post_id ) {
	if (
		! isset( $_POST['videolab_content_nonce'] ) ||
		! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['videolab_content_nonce'] ) ), 'videolab_content_save_meta' ) ||
		( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE )
	) {
		return;
	}

	if ( 'work' === get_post_type( $post_id ) && current_user_can( 'edit_post', $post_id ) ) {
		$fields = array(
			'videolab_origin'           => 'videolab_content_sanitize_origin',
			'videolab_client'           => 'sanitize_text_field',
			'videolab_dates'            => 'sanitize_text_field',
			'videolab_confirmed_results'=> 'sanitize_textarea_field',
			'videolab_video_url'        => 'esc_url_raw',
			'videolab_gallery_ids'      => 'videolab_content_sanitize_ids',
		);
	} elseif ( 'page' === get_post_type( $post_id ) && current_user_can( 'edit_page', $post_id ) ) {
		$fields = array(
			'videolab_service_key'       => 'videolab_content_sanitize_service_key',
			'videolab_starting_price_eur'=> 'absint',
			'videolab_price_period'      => 'sanitize_text_field',
			'videolab_price_note'        => 'sanitize_textarea_field',
			'videolab_scope'             => 'sanitize_textarea_field',
			'videolab_exclusions'        => 'sanitize_textarea_field',
			'videolab_cta'               => 'sanitize_text_field',
			'videolab_viewer_mode'       => 'videolab_content_sanitize_viewer_mode',
		);

		if (
			isset( $_POST['videolab_service_key'] )
			&& '' === videolab_content_sanitize_service_key( wp_unslash( $_POST['videolab_service_key'] ) )
		) {
			foreach ( array_keys( $fields ) as $key ) {
				delete_post_meta( $post_id, $key );
			}
			return;
		}
	} else {
		return;
	}

	foreach ( $fields as $key => $sanitizer ) {
		if ( isset( $_POST[ $key ] ) ) {
			update_post_meta( $post_id, $key, call_user_func( $sanitizer, wp_unslash( $_POST[ $key ] ) ) );
		}
	}
}
add_action( 'save_post', 'videolab_content_save_meta' );

/**
 * Registers the project blocks without a JavaScript build step.
 */
function videolab_content_register_blocks() {
	wp_register_script(
		'videolab-content-blocks',
		VIDEOLAB_CONTENT_URL . 'assets/editor-blocks.js',
		array( 'wp-blocks', 'wp-block-editor', 'wp-components', 'wp-element', 'wp-i18n', 'wp-server-side-render' ),
		VIDEOLAB_CONTENT_VERSION,
		true
	);
	wp_register_script(
		'videolab-image-comparison',
		VIDEOLAB_CONTENT_URL . 'assets/image-comparison.js',
		array(),
		VIDEOLAB_CONTENT_VERSION,
		true
	);
	wp_register_script(
		'videolab-hero-media',
		VIDEOLAB_CONTENT_URL . 'assets/hero-media.js',
		array(),
		VIDEOLAB_CONTENT_VERSION,
		true
	);
	wp_register_style(
		'videolab-content-blocks',
		VIDEOLAB_CONTENT_URL . 'assets/blocks.css',
		array(),
		VIDEOLAB_CONTENT_VERSION
	);
	wp_localize_script(
		'videolab-content-blocks',
		'videolabContentEditor',
		array(
			'worksUrl' => admin_url( 'edit.php?post_type=work' ),
			'mediaUrl' => admin_url( 'upload.php' ),
		)
	);

	$shared = array(
		'api_version'   => 3,
		'editor_script' => 'videolab-content-blocks',
		'style'         => 'videolab-content-blocks',
	);
	register_block_type(
		'videolab/service-prices',
		array_merge( $shared, array( 'render_callback' => 'videolab_content_render_service_prices' ) )
	);
	register_block_type(
		'videolab/work-grid',
		array_merge(
			$shared,
			array(
				'render_callback' => 'videolab_content_render_work_grid',
				'attributes'      => array(
					'note' => array(
						'type'    => 'string',
						'default' => videolab_content_default_work_note(),
					),
				),
			)
		)
	);
	register_block_type(
		'videolab/work-meta',
		array_merge( $shared, array( 'render_callback' => 'videolab_content_render_work_meta' ) )
	);
	register_block_type(
		'videolab/work-results',
		array_merge( $shared, array( 'render_callback' => 'videolab_content_render_work_results' ) )
	);
	register_block_type(
		'videolab/image-comparison',
		array_merge(
			$shared,
			array(
				'view_script'     => 'videolab-image-comparison',
				'render_callback' => 'videolab_content_render_image_comparison',
				'attributes'      => array(
					'dayId'        => array( 'type' => 'integer', 'default' => 0 ),
					'eveningId'    => array( 'type' => 'integer', 'default' => 0 ),
					'dayLabel'     => array( 'type' => 'string', 'default' => 'DIENA' ),
					'eveningLabel' => array( 'type' => 'string', 'default' => 'VAKARAS' ),
				),
			)
		)
	);
	register_block_type(
		'videolab/hero-media',
		array_merge(
			$shared,
			array(
				'view_script'     => 'videolab-hero-media',
				'render_callback' => 'videolab_content_render_hero_media',
				'supports'        => array(
					'align' => array( 'full' ),
					'html'  => false,
				),
				'attributes'      => array(
					'align'   => array(
						'type'    => 'string',
						'default' => 'full',
					),
					'imageId' => array(
						'type'    => 'integer',
						'default' => 0,
					),
					'videoId' => array(
						'type'    => 'integer',
						'default' => 0,
					),
					'alt'     => array(
						'type'    => 'string',
						'default' => '',
					),
					'ctaText' => array(
						'type'    => 'string',
						'default' => videolab_content_default_hero_cta(),
					),
					'ctaUrl'  => array(
						'type'    => 'string',
						'default' => '#stebesena',
					),
					'label'   => array(
						'type'    => 'string',
						'default' => '01 / PROJEKTŲ STEBĖSENA',
					),
				),
			)
		)
	);
}
add_action( 'init', 'videolab_content_register_blocks', 20 );

function videolab_content_render_service_prices() {
	$services = get_posts(
		array(
			'post_type'      => 'page',
			'post_status'    => array( 'publish', 'draft', 'private' ),
			'posts_per_page' => 3,
			'meta_query'     => array(
				array(
					'key'     => 'videolab_service_key',
					'value'   => array( 'monitoring', 'periodic', 'product' ),
					'compare' => 'IN',
				),
			),
			'orderby'        => 'menu_order',
			'order'          => 'ASC',
		)
	);
	if ( ! $services ) {
		return '<p>' . esc_html__( 'Paslaugų duomenys dar nesukurti.', 'videolab-content' ) . '</p>';
	}

	$output = '<div class="vl-service-list">';
	foreach ( $services as $index => $service ) {
		$key         = get_post_meta( $service->ID, 'videolab_service_key', true );
		$price       = (int) get_post_meta( $service->ID, 'videolab_starting_price_eur', true );
		$period      = get_post_meta( $service->ID, 'videolab_price_period', true );
		$scope       = get_post_meta( $service->ID, 'videolab_scope', true );
		$exclusions  = get_post_meta( $service->ID, 'videolab_exclusions', true );
		$cta         = get_post_meta( $service->ID, 'videolab_cta', true );
		$anchor      = 'monitoring' === $key ? '#stebesena' : '#kontaktai';
		$description = get_the_excerpt( $service );
		$output     .= '<details class="vl-service">';
		$output     .= '<summary><span class="vl-service__number">' . esc_html( sprintf( '%02d', $index + 1 ) ) . '</span>';
		$output     .= '<h3>' . esc_html( get_the_title( $service ) ) . '</h3>';
		$output     .= '<span class="vl-service__description">' . esc_html( $description ) . '</span>';
		$output     .= '<strong class="vl-service__price">' . esc_html( 'nuo ' . number_format( $price, 0, ',', ' ' ) . ' €' . ( $period ? ' ' . $period : '' ) ) . '</strong>';
		$output     .= '<span class="vl-service__arrow" aria-hidden="true"></span></summary>';
		$output     .= '<div class="vl-service__body"><p>' . esc_html( $scope ) . '</p><div><p>' . esc_html( $exclusions ) . '</p>';
		$output     .= '<a class="vl-text-link" href="' . esc_url( $anchor ) . '">' . esc_html( $cta ?: __( 'Aptarti paslaugą', 'videolab-content' ) ) . ' <span class="vl-arrow" aria-hidden="true"></span></a></div></div></details>';
	}
	return $output . '</div>';
}

function videolab_content_default_work_note() {
	return __( 'AI koncepcijos aiškiai pažymėtos ir nėra pristatomos kaip klientų projektai.', 'videolab-content' );
}

function videolab_content_default_hero_cta() {
	return __( 'nuo proceso iki rezultato', 'videolab-content' );
}

function videolab_content_hero_video_source( $video_id ) {
	$video_id = absint( $video_id );
	if ( ! $video_id ) {
		return array();
	}

	$url  = wp_get_attachment_url( $video_id );
	$mime = get_post_mime_type( $video_id );
	if ( ! $url || ! is_string( $mime ) || ! str_starts_with( $mime, 'video/' ) ) {
		return array();
	}

	return array(
		'url'  => $url,
		'mime' => $mime,
	);
}

function videolab_content_render_hero_media( $attributes = array() ) {
	$image_id = absint( $attributes['imageId'] ?? 0 );
	$video    = videolab_content_hero_video_source( $attributes['videoId'] ?? 0 );
	$alt      = sanitize_text_field( $attributes['alt'] ?? '' );
	$cta_text = trim( wp_strip_all_tags( (string) ( $attributes['ctaText'] ?? '' ) ) );
	$cta_url  = (string) ( $attributes['ctaUrl'] ?? '#stebesena' );
	$label    = trim( wp_strip_all_tags( (string) ( $attributes['label'] ?? '' ) ) );

	if ( '' === $cta_text ) {
		$cta_text = videolab_content_default_hero_cta();
	}
	if ( ! $image_id && ! $video ) {
		return current_user_can( 'edit_posts' )
			? '<p>' . esc_html__( 'Pasirinkite hero nuotrauką arba video.', 'videolab-content' ) . '</p>'
			: '';
	}

	$classes = array( 'vl-hero-block' );
	if ( $image_id ) {
		$classes[] = 'vl-hero-block--has-image';
	}
	if ( $video ) {
		$classes[] = 'vl-hero-block--has-video';
	}

	$wrapper = get_block_wrapper_attributes(
		array(
			'class' => implode( ' ', $classes ),
		)
	);

	$output  = '<div ' . $wrapper . '>';
	$output .= '<div class="vl-hero-media">';

	if ( $image_id ) {
		$img_alt = '' !== $alt ? $alt : (string) get_post_meta( $image_id, '_wp_attachment_image_alt', true );
		$output .= wp_get_attachment_image(
			$image_id,
			'videolab-hero',
			false,
			array(
				'class'         => 'vl-hero-media__image',
				'alt'           => $img_alt,
				'loading'       => 'eager',
				'fetchpriority' => 'high',
				'decoding'      => 'async',
				'sizes'         => '100vw',
			)
		);
	}

	if ( $video ) {
		$poster  = $image_id ? wp_get_attachment_image_url( $image_id, 'videolab-hero' ) : '';
		$output .= '<video class="vl-hero-media__video" autoplay muted loop playsinline preload="metadata"' . ( $poster ? ' poster="' . esc_url( $poster ) . '"' : '' ) . '>';
		$output .= '<source src="' . esc_url( $video['url'] ) . '" type="' . esc_attr( $video['mime'] ) . '">';
		$output .= '</video>';
	}

	$output .= '</div>';
	$output .= '<div class="vl-hero-bar">';
	$output .= '<a class="wp-element-button" href="' . esc_url( $cta_url ) . '">' . esc_html( $cta_text ) . ' <span class="vl-arrow" aria-hidden="true"></span></a>';
	if ( '' !== $label ) {
		$output .= '<p class="vl-hero-label">' . esc_html( $label ) . '</p>';
	}
	$output .= '</div></div>';

	return $output;
}

function videolab_content_render_work_grid( $attributes = array() ) {
	$works = get_posts(
		array(
			'post_type'      => 'work',
			'post_status'    => 'publish',
			'posts_per_page' => 3,
			'orderby'        => 'menu_order',
			'order'          => 'ASC',
		)
	);
	if ( ! $works ) {
		return '<p>' . esc_html__( 'Publikuotų darbų dar nėra.', 'videolab-content' ) . '</p>';
	}

	$output = '<div class="vl-work-grid">';
	foreach ( $works as $index => $work ) {
		$origin = get_post_meta( $work->ID, 'videolab_origin', true );
		$terms  = get_the_terms( $work, 'work_service' );
		$label  = $terms && ! is_wp_error( $terms ) ? $terms[0]->name : __( 'Darbas', 'videolab-content' );
		$image  = get_the_post_thumbnail( $work, 'videolab-card', array( 'loading' => 0 === $index ? 'eager' : 'lazy' ) );
		$output .= '<article class="vl-work-card"><a href="' . esc_url( get_permalink( $work ) ) . '">';
		$output .= $image;
		if ( 'ai_concept' === $origin ) {
			$output .= '<span class="vl-badge">' . esc_html__( 'AI KONCEPCIJA', 'videolab-content' ) . '</span>';
		}
		$label  = function_exists( 'mb_strtoupper' ) ? mb_strtoupper( $label ) : strtoupper( $label );
		$output .= '<span class="vl-work-card__bottom"><span><small>' . esc_html( sprintf( '%02d / %s', $index + 1, $label ) ) . '</small>';
		$output .= '<strong>' . esc_html( get_the_title( $work ) ) . '</strong></span><b class="vl-arrow" aria-hidden="true"></b></span></a></article>';
	}
	$output .= '</div>';

	$note = isset( $attributes['note'] ) ? trim( wp_strip_all_tags( (string) $attributes['note'] ) ) : '';
	if ( '' !== $note ) {
		$output .= '<p class="vl-work-note">' . esc_html( $note ) . '</p>';
	}

	return $output;
}

function videolab_content_render_work_meta() {
	$post_id = get_the_ID();
	if ( 'work' !== get_post_type( $post_id ) ) {
		return '';
	}
	$origin = get_post_meta( $post_id, 'videolab_origin', true );
	$client = get_post_meta( $post_id, 'videolab_client', true );
	$dates  = get_post_meta( $post_id, 'videolab_dates', true );
	$terms  = get_the_terms( $post_id, 'work_service' );
	$output = '<div class="vl-work-meta">';
	if ( 'ai_concept' === $origin ) {
		$output .= '<span class="vl-origin-concept">' . esc_html__( 'AI koncepcija', 'videolab-content' ) . '</span>';
	}
	if ( $terms && ! is_wp_error( $terms ) ) {
		$output .= '<span><strong>' . esc_html__( 'Kryptis', 'videolab-content' ) . '</strong>' . esc_html( $terms[0]->name ) . '</span>';
	}
	if ( $client ) {
		$output .= '<span><strong>' . esc_html__( 'Klientas', 'videolab-content' ) . '</strong>' . esc_html( $client ) . '</span>';
	}
	if ( $dates ) {
		$output .= '<span><strong>' . esc_html__( 'Data', 'videolab-content' ) . '</strong>' . esc_html( $dates ) . '</span>';
	}
	return $output . '</div>';
}

function videolab_content_render_work_results() {
	$results = get_post_meta( get_the_ID(), 'videolab_confirmed_results', true );
	if ( ! $results ) {
		return '';
	}
	return '<section class="vl-results alignwide"><h2>' . esc_html__( 'patvirtinti rezultatai.', 'videolab-content' ) . '</h2><p>' . nl2br( esc_html( $results ) ) . '</p></section>';
}

function videolab_content_render_image_comparison( $attributes ) {
	$day_id     = absint( $attributes['dayId'] ?? 0 );
	$evening_id = absint( $attributes['eveningId'] ?? 0 );
	if ( ! $day_id || ! $evening_id ) {
		return current_user_can( 'edit_posts' ) ? '<p>' . esc_html__( 'Pasirinkite abu palyginimo vaizdus.', 'videolab-content' ) . '</p>' : '';
	}
	$day_label     = sanitize_text_field( $attributes['dayLabel'] ?? 'DIENA' );
	$evening_label = sanitize_text_field( $attributes['eveningLabel'] ?? 'VAKARAS' );
	$image_sizes   = videolab_content_comparison_image_sizes( $day_id, $evening_id );
	$image_attrs   = array(
		'loading'                  => 'lazy',
		'sizes'                    => $image_sizes,
		'data-vl-comparison-image' => 'evening',
	);

	$output  = '<div class="vl-comparison" data-vl-comparison>';
	$output .= '<div class="vl-comparison__frame">';
	$output .= wp_get_attachment_image( $evening_id, 'videolab-hero', false, $image_attrs );
	$output .= wp_get_attachment_image(
		$day_id,
		'videolab-hero',
		false,
		array_merge(
			$image_attrs,
			array(
				'class'                    => 'vl-comparison__top wp-image-' . $day_id,
				'data-vl-comparison-image' => 'day',
			)
		)
	);

	$output .= '<span class="vl-comparison__label vl-comparison__label--left">' . esc_html( $day_label ) . '</span>';
	$output .= '<span class="vl-comparison__label vl-comparison__label--right">' . esc_html( $evening_label ) . '</span>';
	$output .= '<span class="vl-comparison__line" aria-hidden="true"></span></div>';
	$output .= '<label>' . esc_html__( 'Palyginti kadrus', 'videolab-content' ) . '<span class="vl-arrow vl-arrow--ew" aria-hidden="true"></span></label>';
	$output .= '<input type="range" min="0" max="100" value="50" aria-label="' . esc_attr__( 'Dienos ir vakaro kadrų palyginimas', 'videolab-content' ) . '">';
	return $output . '</div>';
}

/**
 * Comparison frame is 16/10 with object-fit: cover. Wider photos are scaled
 * by height and cropped on the sides, so srcset must use a larger slot than
 * the CSS box width.
 */
function videolab_content_comparison_cover_factor( $attachment_id ) {
	$box_aspect = 1.6;
	$src        = wp_get_attachment_image_src( absint( $attachment_id ), 'videolab-hero' );
	if ( ! $src || empty( $src[1] ) || empty( $src[2] ) ) {
		return 1.2;
	}

	$image_aspect = (float) $src[1] / (float) $src[2];
	return max( 1, round( $image_aspect / $box_aspect, 3 ) );
}

function videolab_content_comparison_image_sizes( $day_id, $evening_id ) {
	$factor  = max(
		videolab_content_comparison_cover_factor( $day_id ),
		videolab_content_comparison_cover_factor( $evening_id )
	);
	$desktop = (int) ceil( 760 * $factor );

	return sprintf(
		'(max-width: 700px) calc((100vw - 36px) * %1$s), (max-width: 1100px) calc((100vw - 91px) * 0.55 * %1$s), %2$dpx',
		$factor,
		$desktop
	);
}

/**
 * Lazy unique images would otherwise get sizes=auto from the clipped day
 * frame (~half width) and pick a 768px file.
 */
function videolab_content_disable_comparison_auto_sizes( $add, $image = '' ) {
	if ( is_string( $image ) && false !== strpos( $image, 'data-vl-comparison-image' ) ) {
		return false;
	}
	return $add;
}
add_filter( 'wp_img_tag_add_auto_sizes', 'videolab_content_disable_comparison_auto_sizes', 10, 2 );

/**
 * Keeps lazy loading while replacing Core's unstable auto-sizes calculation
 * with the comparison block's explicit responsive sizes.
 */
function videolab_content_filter_comparison_image_sizes( $image ) {
	$processor = new WP_HTML_Tag_Processor( $image );
	if ( ! $processor->next_tag( array( 'tag_name' => 'IMG' ) ) || ! $processor->get_attribute( 'data-vl-comparison-image' ) ) {
		return $image;
	}

	$sizes = $processor->get_attribute( 'sizes' );
	if ( ! is_string( $sizes ) ) {
		return $image;
	}

	$fixed_sizes = preg_replace( '/^\s*auto\s*,\s*/i', '', $sizes );
	if ( ! is_string( $fixed_sizes ) || $fixed_sizes === $sizes ) {
		return $image;
	}

	$processor->set_attribute( 'sizes', $fixed_sizes );
	return $processor->get_updated_html();
}
add_filter( 'wp_content_img_tag', 'videolab_content_filter_comparison_image_sizes' );

/**
 * Loads the native media picker only on relevant editor screens.
 */
function videolab_content_admin_assets( $hook ) {
	if ( ! in_array( $hook, array( 'post.php', 'post-new.php' ), true ) || 'work' !== get_current_screen()->post_type ) {
		return;
	}
	wp_enqueue_media();
	wp_enqueue_script(
		'videolab-content-admin',
		VIDEOLAB_CONTENT_URL . 'assets/admin.js',
		array( 'jquery' ),
		VIDEOLAB_CONTENT_VERSION,
		true
	);
}
add_action( 'admin_enqueue_scripts', 'videolab_content_admin_assets' );

require_once VIDEOLAB_CONTENT_DIR . 'inc/seed.php';
