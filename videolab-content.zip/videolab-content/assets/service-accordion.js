(function () {
	'use strict';

	function items(list) {
		return list.querySelectorAll(':scope > details.vl-service');
	}

	function syncItem(item) {
		var summary = item.querySelector('summary');
		var body = item.querySelector('.vl-service__body');
		if (summary) {
			summary.setAttribute('aria-expanded', item.open ? 'true' : 'false');
		}
		if (!body) {
			return;
		}
		var focusables = body.querySelectorAll('a, button, input, select, textarea, [href], [tabindex]');
		if (item.open) {
			body.removeAttribute('inert');
			focusables.forEach(function (el) {
				if (!el.hasAttribute('data-vl-tab')) {
					return;
				}
				var prev = el.getAttribute('data-vl-tab');
				el.removeAttribute('data-vl-tab');
				if (prev === '') {
					el.removeAttribute('tabindex');
				} else {
					el.setAttribute('tabindex', prev);
				}
			});
			return;
		}
		body.setAttribute('inert', '');
		focusables.forEach(function (el) {
			if (!el.hasAttribute('data-vl-tab')) {
				el.setAttribute('data-vl-tab', el.hasAttribute('tabindex') ? el.getAttribute('tabindex') : '');
			}
			el.setAttribute('tabindex', '-1');
		});
	}

	function closeOthers(list, except) {
		items(list).forEach(function (item) {
			if (item !== except && item.open) {
				item.open = false;
			}
			if (item !== except) {
				syncItem(item);
			}
		});
	}

	function resetList(list) {
		items(list).forEach(function (item) {
			item.open = false;
			syncItem(item);
		});
	}

	function onToggle(list, item) {
		syncItem(item);
		if (item.open) {
			closeOthers(list, item);
		}
	}

	function bind(list) {
		if (list.getAttribute('data-vl-bound') === '1') {
			return;
		}
		list.setAttribute('data-vl-bound', '1');

		items(list).forEach(function (item) {
			var summary = item.querySelector('summary');
			item.open = false;
			syncItem(item);
			item.addEventListener('toggle', function () {
				onToggle(list, item);
			});
			if (summary) {
				summary.addEventListener('click', function () {
					window.requestAnimationFrame(function () {
						onToggle(list, item);
					});
				});
			}
		});
	}

	function bindAll() {
		document.querySelectorAll('[data-vl-service-accordion]').forEach(bind);
	}

	function resetAll() {
		document.querySelectorAll('[data-vl-service-accordion]').forEach(resetList);
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', bindAll);
	} else {
		bindAll();
	}

	window.addEventListener('pageshow', function () {
		bindAll();
		resetAll();
	});
})();
