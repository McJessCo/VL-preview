(function () {
	'use strict';

	function activeVideos(root) {
		return Array.prototype.filter.call(root.querySelectorAll('video'), function (video) {
			return getComputedStyle(video).display !== 'none';
		});
	}

	function setPaused(root, paused) {
		const button = root.querySelector('.vl-hero-media__toggle');
		const videos = root.querySelectorAll('video');
		videos.forEach(function (video) {
			if (paused) {
				video.pause();
				video.removeAttribute('autoplay');
			} else {
				const play = video.play();
				if (play && typeof play.catch === 'function') {
					play.catch(function () {
						setPaused(root, true);
					});
				}
			}
		});
		root.classList.toggle('is-playing', !paused);
		if (!button) {
			return;
		}
		button.classList.toggle('is-paused', paused);
		button.setAttribute('aria-pressed', paused ? 'false' : 'true');
		button.setAttribute('aria-label', paused ? 'Paleisti video' : 'Pristabdyti video');
	}

	function setup(root) {
		const videos = root.querySelectorAll('video');
		const button = root.querySelector('.vl-hero-media__toggle');
		if (!videos.length || !button) {
			return;
		}

		const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
		if (reduce) {
			setPaused(root, true);
			videos.forEach(function (video) {
				video.currentTime = 0;
			});
		} else {
			activeVideos(root).forEach(function (video) {
				const play = video.play();
				if (play && typeof play.catch === 'function') {
					play.catch(function () {
						setPaused(root, true);
					});
				}
			});
		}

		button.addEventListener('click', function () {
			const playing = activeVideos(root).some(function (video) {
				return !video.paused;
			});
			setPaused(root, playing);
		});
	}

	document.querySelectorAll('.vl-hero-block--has-video').forEach(setup);
})();
