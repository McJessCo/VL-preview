(function () {
	'use strict';

	if (!window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
		return;
	}

	document.querySelectorAll('.vl-hero-media__video').forEach(function (video) {
		video.pause();
		video.removeAttribute('autoplay');
		video.currentTime = 0;
	});
})();
