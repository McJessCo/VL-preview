(function (blocks, blockEditor, components, element, i18n, ServerSideRender) {
	'use strict';

	const el = element.createElement;
	const Fragment = element.Fragment;
	const MediaUpload = blockEditor.MediaUpload;
	const MediaUploadCheck = blockEditor.MediaUploadCheck;
	const InspectorControls = blockEditor.InspectorControls;
	const Button = components.Button;
	const PanelBody = components.PanelBody;
	const TextControl = components.TextControl;
	const __ = i18n.__;

	function registerDynamic(name, title, description, icon) {
		blocks.registerBlockType(name, {
			apiVersion: 3,
			title: title,
			description: description,
			category: 'widgets',
			icon: icon,
			edit: function () {
				return el(ServerSideRender, { block: name });
			},
			save: function () {
				return null;
			}
		});
	}

	registerDynamic(
		'videolab/service-prices',
		__('Video Lab paslaugos ir kainos', 'videolab-content'),
		__('Skaito vienintelį kainų šaltinį iš paslaugų puslapių.', 'videolab-content'),
		'editor-table'
	);
	registerDynamic(
		'videolab/work-grid',
		__('Video Lab darbų tinklelis', 'videolab-content'),
		__('Rodo publikuotus darbus ir jų kilmės žymą.', 'videolab-content'),
		'format-gallery'
	);
	registerDynamic(
		'videolab/work-meta',
		__('Video Lab darbo duomenys', 'videolab-content'),
		__('Rodo paslaugos kryptį, kilmę ir tik užpildytus patvirtintus laukus.', 'videolab-content'),
		'info-outline'
	);
	registerDynamic(
		'videolab/work-results',
		__('Video Lab patvirtinti rezultatai', 'videolab-content'),
		__('Nieko nerodo, kol darbo laukas paliktas tuščias.', 'videolab-content'),
		'yes-alt'
	);

	blocks.registerBlockType('videolab/image-comparison', {
		apiVersion: 3,
		title: __('Video Lab kadrų palyginimas', 'videolab-content'),
		description: __('Du nepriklausomai pasirenkami vaizdai su prieinamu slankikliu.', 'videolab-content'),
		category: 'media',
		icon: 'image-flip-horizontal',
		attributes: {
			dayId: { type: 'integer', default: 0 },
			eveningId: { type: 'integer', default: 0 },
			dayLabel: { type: 'string', default: 'DIENA' },
			eveningLabel: { type: 'string', default: 'VAKARAS' }
		},
		edit: function (props) {
			const attributes = props.attributes;
			const setAttributes = props.setAttributes;
			const ready = attributes.dayId && attributes.eveningId;

			function picker(label, attribute) {
				return el(
					MediaUploadCheck,
					null,
					el(MediaUpload, {
						allowedTypes: ['image'],
						value: attributes[attribute],
						onSelect: function (media) {
							const update = {};
							update[attribute] = media.id;
							setAttributes(update);
						},
						render: function (upload) {
							return el(
								Button,
								{ variant: 'secondary', onClick: upload.open },
								label
							);
						}
					})
				);
			}

			return el(
				Fragment,
				null,
				el(
					InspectorControls,
					null,
					el(
						PanelBody,
						{ title: __('Žymos', 'videolab-content'), initialOpen: true },
						el(TextControl, {
							label: __('Kairė žyma', 'videolab-content'),
							value: attributes.dayLabel,
							onChange: function (value) { setAttributes({ dayLabel: value }); }
						}),
						el(TextControl, {
							label: __('Dešinė žyma', 'videolab-content'),
							value: attributes.eveningLabel,
							onChange: function (value) { setAttributes({ eveningLabel: value }); }
						})
					)
				),
				el(
					'div',
					{ className: props.className },
					el(
						'div',
						{ className: 'vl-editor-media-actions' },
						picker(__('Pasirinkti dienos kadrą', 'videolab-content'), 'dayId'),
						picker(__('Pasirinkti vakaro kadrą', 'videolab-content'), 'eveningId')
					),
					ready
						? el(ServerSideRender, { block: 'videolab/image-comparison', attributes: attributes })
						: el('p', null, __('Pasirinkite abu vaizdus.', 'videolab-content'))
				)
			);
		},
		save: function () {
			return null;
		}
	});
}(
	window.wp.blocks,
	window.wp.blockEditor,
	window.wp.components,
	window.wp.element,
	window.wp.i18n,
	window.wp.serverSideRender
));
