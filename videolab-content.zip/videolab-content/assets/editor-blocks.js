(function (blocks, blockEditor, components, element, i18n, ServerSideRender) {
	'use strict';

	const el = element.createElement;
	const Fragment = element.Fragment;
	const MediaUpload = blockEditor.MediaUpload;
	const MediaUploadCheck = blockEditor.MediaUploadCheck;
	const InspectorControls = blockEditor.InspectorControls;
	const RichText = blockEditor.RichText;
	const Button = components.Button;
	const PanelBody = components.PanelBody;
	const TextControl = components.TextControl;
	const TextareaControl = components.TextareaControl;
	const RangeControl = components.RangeControl;
	const FocalPointPicker = components.FocalPointPicker || blockEditor.FocalPointPicker;
	const __ = i18n.__;
	const worksUrl = (window.videolabContentEditor && window.videolabContentEditor.worksUrl) || 'edit.php?post_type=work';
	const mediaUrl = (window.videolabContentEditor && window.videolabContentEditor.mediaUrl) || 'upload.php';

	function registerDynamic(name, title, description, icon) {
		blocks.registerBlockType(name, {
			apiVersion: 3,
			title: title,
			description: description,
			category: 'widgets',
			icon: icon,
			edit: function () {
				return el(ServerSideRender, { block: name });
			},
			save: function () {
				return null;
			}
		});
	}

	registerDynamic(
		'videolab/service-prices',
		__('Video Lab paslaugos ir kainos', 'videolab-content'),
		__('Skaito vienintelį kainų šaltinį iš paslaugų puslapių.', 'videolab-content'),
		'editor-table'
	);
	blocks.registerBlockType('videolab/work-grid', {
		apiVersion: 3,
		title: __('Video Lab darbų tinklelis', 'videolab-content'),
		description: __('Rodo publikuotus darbus. Kortelės imamos iš darbų įrašų, pastaba po jomis redaguojama čia.', 'videolab-content'),
		category: 'widgets',
		icon: 'format-gallery',
		attributes: {
			note: {
				type: 'string',
				default: __('AI koncepcijos aiškiai pažymėtos ir nėra pristatomos kaip klientų projektai.', 'videolab-content')
			}
		},
		edit: function (props) {
			const attributes = props.attributes;
			const setAttributes = props.setAttributes;

			return el(
				Fragment,
				null,
				el(
					InspectorControls,
					null,
					el(
						PanelBody,
						{ title: __('Darbų tinklelis', 'videolab-content'), initialOpen: true },
						el(
							'p',
							null,
							__('Kortelių pavadinimai, nuotraukos, paslaugos kryptis ir AI žyma imami iš darbų įrašų. Antraštė virš tinklelio redaguojama atskirame antraštės bloke.', 'videolab-content')
						),
						el(
							'p',
							null,
							el(
								'a',
								{ href: worksUrl, target: '_blank', rel: 'noopener noreferrer' },
								__('Redaguoti darbus', 'videolab-content')
							)
						),
						el(TextareaControl, {
							label: __('Pastaba po kortelėmis', 'videolab-content'),
							value: attributes.note,
							onChange: function (value) { setAttributes({ note: value }); },
							help: __('Šis tekstas matomas lankytojams. Tuščias laukas pastabos nerodo.', 'videolab-content')
						})
					)
				),
				el(
					'div',
					{ className: props.className },
					el(
						'div',
						{ className: 'vl-editor-hint' },
						el(
							'p',
							null,
							__('Kortelės atnaujinamos iš Darbai įrašų. Čia keičiama tik pastaba po tinkleliu.', 'videolab-content')
						),
						el(
							'a',
							{ className: 'vl-editor-hint__link', href: worksUrl, target: '_blank', rel: 'noopener noreferrer' },
							__('Redaguoti darbus', 'videolab-content')
						)
					),
					el(ServerSideRender, {
						block: 'videolab/work-grid',
						attributes: Object.assign({}, attributes, { note: '' })
					}),
					el(RichText, {
						tagName: 'p',
						className: 'vl-work-note',
						value: attributes.note,
						allowedFormats: [],
						placeholder: __('Pastaba po kortelėmis', 'videolab-content'),
						onChange: function (value) { setAttributes({ note: value }); }
					})
				)
			);
		},
		save: function () {
			return null;
		}
	});
	registerDynamic(
		'videolab/work-meta',
		__('Video Lab darbo duomenys', 'videolab-content'),
		__('Rodo paslaugos kryptį, kilmę ir tik užpildytus patvirtintus laukus.', 'videolab-content'),
		'info-outline'
	);
	registerDynamic(
		'videolab/work-results',
		__('Video Lab patvirtinti rezultatai', 'videolab-content'),
		__('Nieko nerodo, kol darbo laukas paliktas tuščias.', 'videolab-content'),
		'yes-alt'
	);

	blocks.registerBlockType('videolab/image-comparison', {
		apiVersion: 3,
		title: __('Video Lab kadrų palyginimas', 'videolab-content'),
		description: __('Du nepriklausomai pasirenkami vaizdai su prieinamu slankikliu. Žymos redaguojamos čia.', 'videolab-content'),
		category: 'media',
		icon: 'image-flip-horizontal',
		attributes: {
			dayId: { type: 'integer', default: 0 },
			eveningId: { type: 'integer', default: 0 },
			dayLabel: { type: 'string', default: 'DIENA' },
			eveningLabel: { type: 'string', default: 'VAKARAS' }
		},
		edit: function (props) {
			const attributes = props.attributes;
			const setAttributes = props.setAttributes;
			const ready = attributes.dayId && attributes.eveningId;

			function picker(label, attribute) {
				return el(
					MediaUploadCheck,
					null,
					el(MediaUpload, {
						allowedTypes: ['image'],
						value: attributes[attribute],
						onSelect: function (media) {
							const update = {};
							update[attribute] = media.id;
							setAttributes(update);
						},
						render: function (upload) {
							return el(
								Button,
								{ variant: 'secondary', onClick: upload.open },
								label
							);
						}
					})
				);
			}

			return el(
				Fragment,
				null,
				el(
					InspectorControls,
					null,
					el(
						PanelBody,
						{ title: __('Kadrų palyginimas', 'videolab-content'), initialOpen: true },
						el(
							'p',
							null,
							__('Kadrai keičiami per Media Library. Antraštė ir pastraipos šalia bloko redaguojamos kaip atskiri blokai. Čia keičiamos tik žymos ant kadrų.', 'videolab-content')
						),
						el(
							'p',
							null,
							el(
								'a',
								{ href: mediaUrl, target: '_blank', rel: 'noopener noreferrer' },
								__('Atidaryti mediją', 'videolab-content')
							)
						),
						el(TextControl, {
							label: __('Dienos žyma', 'videolab-content'),
							value: attributes.dayLabel,
							onChange: function (value) { setAttributes({ dayLabel: value }); }
						}),
						el(TextControl, {
							label: __('Vakaro žyma', 'videolab-content'),
							value: attributes.eveningLabel,
							onChange: function (value) { setAttributes({ eveningLabel: value }); }
						})
					)
				),
				el(
					'div',
					{ className: props.className },
					el(
						'div',
						{ className: 'vl-editor-hint' },
						el(
							'p',
							null,
							__('Kadrai keičiami šio bloko mygtukais. Antraštė ir tekstas kairėje – atskiri blokai.', 'videolab-content')
						),
						el(
							'a',
							{ className: 'vl-editor-hint__link', href: mediaUrl, target: '_blank', rel: 'noopener noreferrer' },
							__('Atidaryti mediją', 'videolab-content')
						)
					),
					el(
						'div',
						{ className: 'vl-editor-media-actions' },
						picker(__('Pasirinkti dienos kadrą', 'videolab-content'), 'dayId'),
						picker(__('Pasirinkti vakaro kadrą', 'videolab-content'), 'eveningId')
					),
					ready
						? el(ServerSideRender, { block: 'videolab/image-comparison', attributes: attributes })
						: el('p', null, __('Pasirinkite abu vaizdus.', 'videolab-content')),
					el(
						'div',
						{ className: 'vl-editor-comparison-labels' },
						el(TextControl, {
							label: __('Dienos žyma', 'videolab-content'),
							value: attributes.dayLabel,
							onChange: function (value) { setAttributes({ dayLabel: value }); }
						}),
						el(TextControl, {
							label: __('Vakaro žyma', 'videolab-content'),
							value: attributes.eveningLabel,
							onChange: function (value) { setAttributes({ eveningLabel: value }); }
						})
					)
				)
			);
		},
		save: function () {
			return null;
		}
	});

	blocks.registerBlockType('videolab/hero-media', {
		apiVersion: 3,
		title: __('Video Lab hero medija', 'videolab-content'),
		description: __('Nuotrauka arba video su nuorodos eilute po kadrų. Kadravimo taškas ir medija keičiami redaktoriuje.', 'videolab-content'),
		category: 'widgets',
		icon: 'format-video',
		supports: {
			align: ['full'],
			html: false
		},
		attributes: {
			align: { type: 'string', default: 'full' },
			imageId: { type: 'number', default: 0 },
			videoId: { type: 'number', default: 0 },
			mobileVideoId: { type: 'number', default: 0 },
			focalPoint: { type: 'object', default: { x: 0.56, y: 0.67 } },
			alt: { type: 'string', default: '' },
			ctaText: { type: 'string', default: __('Nuo proceso iki rezultato', 'videolab-content') },
			ctaUrl: { type: 'string', default: '#stebesena' },
			label: { type: 'string', default: '' }
		},
		edit: function (props) {
			const attributes = props.attributes;
			const setAttributes = props.setAttributes;
			const ready = !!(attributes.imageId || attributes.videoId || attributes.mobileVideoId);
			const focal = attributes.focalPoint && typeof attributes.focalPoint.x === 'number'
				? attributes.focalPoint
				: { x: 0.56, y: 0.67 };
			let imageUrl = '';
			if (attributes.imageId && window.wp && wp.data && wp.data.select('core') && wp.data.select('core').getMedia) {
				const media = wp.data.select('core').getMedia(attributes.imageId);
				imageUrl = media && (media.source_url || media.url) || '';
			}

			function picker(label, attr, allowed) {
				return el(
					MediaUploadCheck,
					null,
					el(MediaUpload, {
						onSelect: function (media) {
							const next = {};
							next[attr] = media && media.id ? media.id : 0;
							if (attr === 'imageId' && media && media.alt && !attributes.alt) {
								next.alt = media.alt;
							}
							setAttributes(next);
						},
						allowedTypes: allowed,
						value: attributes[attr] || 0,
						render: function (obj) {
							return el(
								Button,
								{ variant: 'secondary', onClick: obj.open },
								label
							);
						}
					})
				);
			}

			function setFocal(next) {
				setAttributes({
					focalPoint: {
						x: Math.max(0, Math.min(1, next.x)),
						y: Math.max(0, Math.min(1, next.y))
					}
				});
			}

			return el(
				Fragment,
				null,
				el(
					InspectorControls,
					null,
					el(
						PanelBody,
						{ title: __('Hero medija', 'videolab-content'), initialOpen: true },
						el(
							'p',
							null,
							__('Nuotrauka naudojama ir kaip video posteris. Video ir mobilus video neprivalomi. Kol video nepriskirtas, paleidimo valdiklis nerodomas.', 'videolab-content')
						),
						el(
							'p',
							null,
							el(
								'a',
								{ href: mediaUrl, target: '_blank', rel: 'noopener noreferrer' },
								__('Atidaryti mediją', 'videolab-content')
							)
						),
						FocalPointPicker && imageUrl
							? el(FocalPointPicker, {
								url: imageUrl,
								value: focal,
								onChange: setFocal,
								label: __('Kadravimo taškas', 'videolab-content')
							})
							: null,
						el(RangeControl, {
							label: __('Kadravimas horizontaliai', 'videolab-content'),
							value: Math.round(focal.x * 100),
							min: 0,
							max: 100,
							onChange: function (value) { setFocal({ x: (value || 0) / 100, y: focal.y }); }
						}),
						el(RangeControl, {
							label: __('Kadravimas vertikaliai', 'videolab-content'),
							value: Math.round(focal.y * 100),
							min: 0,
							max: 100,
							onChange: function (value) { setFocal({ x: focal.x, y: (value || 0) / 100 }); }
						}),
						el(TextControl, {
							label: __('Nuotraukos alt', 'videolab-content'),
							value: attributes.alt,
							onChange: function (value) { setAttributes({ alt: value }); }
						}),
						el(TextControl, {
							label: __('Nuorodos tekstas', 'videolab-content'),
							value: attributes.ctaText,
							onChange: function (value) { setAttributes({ ctaText: value }); }
						}),
						el(TextControl, {
							label: __('Nuorodos adresas', 'videolab-content'),
							value: attributes.ctaUrl,
							onChange: function (value) { setAttributes({ ctaUrl: value }); }
						})
					)
				),
				el(
					'div',
					{ className: props.className },
					el(
						'div',
						{ className: 'vl-editor-hint' },
						el(
							'p',
							null,
							__('Nuotrauka / posteris, video ir kadravimas keičiami čia. Nuoroda eina po kadrų, ne perdanga.', 'videolab-content')
						),
						el(
							'a',
							{ className: 'vl-editor-hint__link', href: mediaUrl, target: '_blank', rel: 'noopener noreferrer' },
							__('Atidaryti mediją', 'videolab-content')
						)
					),
					el(
						'div',
						{ className: 'vl-editor-media-actions' },
						picker(__('Pasirinkti nuotrauką / posterį', 'videolab-content'), 'imageId', ['image']),
						picker(__('Pasirinkti video', 'videolab-content'), 'videoId', ['video']),
						picker(__('Pasirinkti mobilų video', 'videolab-content'), 'mobileVideoId', ['video']),
						attributes.videoId
							? el(
								Button,
								{
									variant: 'tertiary',
									onClick: function () { setAttributes({ videoId: 0 }); }
								},
								__('Pašalinti video', 'videolab-content')
							)
							: null,
						attributes.mobileVideoId
							? el(
								Button,
								{
									variant: 'tertiary',
									onClick: function () { setAttributes({ mobileVideoId: 0 }); }
								},
								__('Pašalinti mobilų video', 'videolab-content')
							)
							: null
					),
					ready
						? el(ServerSideRender, { block: 'videolab/hero-media', attributes: attributes })
						: el('p', null, __('Pasirinkite nuotrauką arba video.', 'videolab-content')),
					el(
						'div',
						{ className: 'vl-editor-hero-fields' },
						el(TextControl, {
							label: __('Nuorodos tekstas', 'videolab-content'),
							value: attributes.ctaText,
							onChange: function (value) { setAttributes({ ctaText: value }); }
						}),
						el(TextControl, {
							label: __('Nuorodos adresas', 'videolab-content'),
							value: attributes.ctaUrl,
							onChange: function (value) { setAttributes({ ctaUrl: value }); }
						})
					)
				)
			);
		},
		save: function () {
			return null;
		}
	});
}(
	window.wp.blocks,
	window.wp.blockEditor,
	window.wp.components,
	window.wp.element,
	window.wp.i18n,
	window.wp.serverSideRender
));
