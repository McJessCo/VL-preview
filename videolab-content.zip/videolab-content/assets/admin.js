(function ($) {
	'use strict';

	$(document).on('click', '.videolab-select-gallery', function (event) {
		event.preventDefault();
		const field = $('#videolab_gallery_ids');
		const frame = wp.media({
			title: 'Pasirinkite darbo galerijos vaizdus',
			button: { text: 'Naudoti galerijoje' },
			library: { type: 'image' },
			multiple: true
		});

		frame.on('select', function () {
			const ids = frame.state().get('selection').map(function (attachment) {
				return attachment.get('id');
			});
			field.val(ids.join(',')).trigger('change');
		});
		frame.open();
	});

	$(document).on('click', '.videolab-select-poster', function (event) {
		event.preventDefault();
		const field = $('#videolab_poster_id');
		const frame = wp.media({
			title: 'Pasirinkite video viršelį',
			button: { text: 'Naudoti viršelį' },
			library: { type: 'image' },
			multiple: false
		});

		frame.on('select', function () {
			const attachment = frame.state().get('selection').first();
			field.val(attachment ? attachment.get('id') : '').trigger('change');
		});
		frame.open();
	});
}(jQuery));
