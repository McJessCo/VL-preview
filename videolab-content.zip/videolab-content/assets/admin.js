(function ($) {
	'use strict';

	$(document).on('click', '.videolab-select-gallery', function (event) {
		event.preventDefault();
		const field = $('#videolab_gallery_ids');
		const frame = wp.media({
			title: 'Pasirinkite darbo galerijos vaizdus',
			button: { text: 'Naudoti galerijoje' },
			library: { type: 'image' },
			multiple: true
		});

		frame.on('select', function () {
			const ids = frame.state().get('selection').map(function (attachment) {
				return attachment.get('id');
			});
			field.val(ids.join(',')).trigger('change');
		});
		frame.open();
	});
}(jQuery));
