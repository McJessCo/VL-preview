(function () {
	'use strict';

	document.querySelectorAll('[data-vl-comparison]').forEach(function (comparison) {
		const input = comparison.querySelector('input[type="range"]');
		const topImage = comparison.querySelector('.vl-comparison__top');
		const line = comparison.querySelector('.vl-comparison__line');

		if (!input || !topImage || !line) {
			return;
		}

		input.addEventListener('input', function () {
			const value = Number(input.value);
			topImage.style.clipPath = 'inset(0 ' + (100 - value) + '% 0 0)';
			line.style.left = value + '%';
		});
	});
}());
