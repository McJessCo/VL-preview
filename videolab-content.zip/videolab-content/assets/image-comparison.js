(function () {
	'use strict';

	var LOCK = 12;

	document.querySelectorAll('[data-vl-comparison]').forEach(function (comparison) {
		const input = comparison.querySelector('input[type="range"]');
		const topImage = comparison.querySelector('.vl-comparison__top');
		const line = comparison.querySelector('.vl-comparison__line');
		const frame = comparison.querySelector('.vl-comparison__frame');

		if (!input || !topImage || !line) {
			return;
		}

		function render() {
			const value = Number(input.value);
			topImage.style.clipPath = 'inset(0 ' + (100 - value) + '% 0 0)';
			line.style.left = value + '%';
		}

		input.addEventListener('input', render);
		render();
		if (!frame) return;

		let activePointer = null;
		let gesture = null;
		let startX = 0;
		let startY = 0;
		let lastY = 0;

		function updateFromPointer(event) {
			const bounds = frame.getBoundingClientRect();
			if (!bounds.width) return;
			input.value = String(Math.round(Math.max(0, Math.min(100,
				(event.clientX - bounds.left) / bounds.width * 100))));
			input.dispatchEvent(new Event('input', { bubbles: true }));
		}

		function lockGesture(event) {
			if (gesture) return gesture;
			var dx = event.clientX - startX;
			var dy = event.clientY - startY;
			if (Math.abs(dx) < LOCK && Math.abs(dy) < LOCK) {
				return null;
			}
			gesture = Math.abs(dx) >= Math.abs(dy) ? 'slide' : 'scroll';
			return gesture;
		}

		frame.addEventListener('pointerdown', function (event) {
			if (!event.isPrimary || event.button !== 0) return;
			activePointer = event.pointerId;
			startX = event.clientX;
			startY = event.clientY;
			lastY = event.clientY;
			gesture = event.pointerType === 'mouse' ? 'slide' : null;
			frame.setPointerCapture(event.pointerId);
			if (gesture === 'slide') {
				updateFromPointer(event);
			}
		});

		frame.addEventListener('pointermove', function (event) {
			if (event.pointerType === 'mouse') {
				updateFromPointer(event);
				return;
			}
			if (event.pointerId !== activePointer) return;
			if (lockGesture(event) === 'slide') {
				updateFromPointer(event);
				return;
			}
			if (gesture === 'scroll') {
				window.scrollBy(0, lastY - event.clientY);
				lastY = event.clientY;
			}
		});

		function release(event) {
			if (event.pointerId !== activePointer) return;
			activePointer = null;
			gesture = null;
			if (frame.hasPointerCapture(event.pointerId)) {
				frame.releasePointerCapture(event.pointerId);
			}
		}

		frame.addEventListener('pointerup', release);
		frame.addEventListener('pointercancel', release);
		frame.addEventListener('lostpointercapture', release);
		frame.addEventListener('dragstart', function (event) { event.preventDefault(); });
	});
}());
