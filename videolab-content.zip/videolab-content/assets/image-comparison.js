(function () {
	'use strict';

	document.querySelectorAll('[data-vl-comparison]').forEach(function (comparison) {
		const input = comparison.querySelector('input[type="range"]');
		const topImage = comparison.querySelector('.vl-comparison__top');
		const line = comparison.querySelector('.vl-comparison__line');
		const frame = comparison.querySelector('.vl-comparison__frame');

		if (!input || !topImage || !line) {
			return;
		}

		function render() {
			const value = Number(input.value);
			topImage.style.clipPath = 'inset(0 ' + (100 - value) + '% 0 0)';
			line.style.left = value + '%';
		}

		input.addEventListener('input', render);
		render();
		if (!frame) return;

		let activePointer = null;
		function updateFromPointer(event) {
			const bounds = frame.getBoundingClientRect();
			if (!bounds.width) return;
			input.value = String(Math.round(Math.max(0, Math.min(100,
				(event.clientX - bounds.left) / bounds.width * 100))));
			input.dispatchEvent(new Event('input', { bubbles: true }));
		}

		frame.addEventListener('pointerdown', function (event) {
			if (!event.isPrimary || event.button !== 0) return;
			activePointer = event.pointerId;
			frame.setPointerCapture(event.pointerId);
			updateFromPointer(event);
		});
		frame.addEventListener('pointermove', function (event) {
			if (event.pointerType === 'mouse' || event.pointerId === activePointer) {
				updateFromPointer(event);
			}
		});
		function release(event) {
			if (event.pointerId !== activePointer) return;
			activePointer = null;
			if (frame.hasPointerCapture(event.pointerId)) frame.releasePointerCapture(event.pointerId);
		}
		frame.addEventListener('pointerup', release);
		frame.addEventListener('pointercancel', release);
		frame.addEventListener('lostpointercapture', release);
		frame.addEventListener('dragstart', function (event) { event.preventDefault(); });
	});
}());
