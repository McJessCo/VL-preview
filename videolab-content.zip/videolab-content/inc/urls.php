<?php
/**
 * Turns root-relative links into WordPress permalinks so Playground
 * keeps its /scope:…/ prefix.
 *
 * @package VideoLabContent
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Converts /, /path and /#hash into home_url() values. Leaves absolute,
 * mailto, tel and already-scoped URLs unchanged.
 *
 * @param string $url Raw href.
 * @return string
 */
function videolab_content_public_url( $url ) {
	if ( ! is_string( $url ) || '' === $url ) {
		return $url;
	}
	if ( preg_match( '#^(https?:|mailto:|tel:|//)#i', $url ) ) {
		return $url;
	}
	if ( isset( $url[0] ) && '#' === $url[0] ) {
		return home_url( '/' ) . $url;
	}
	if ( isset( $url[0] ) && '/' === $url[0] ) {
		return home_url( $url );
	}
	return $url;
}

/**
 * Rewrites href="/…" attributes through home_url().
 *
 * @param string $html Block HTML.
 * @return string
 */
function videolab_content_rewrite_root_hrefs( $html ) {
	if ( ! is_string( $html ) || false === strpos( $html, 'href="' ) ) {
		return $html;
	}

	$rewritten = preg_replace_callback(
		'/href="((?:\/|#)(?:[^"]*)?)"/',
		static function ( $matches ) {
			return 'href="' . esc_url( videolab_content_public_url( $matches[1] ) ) . '"';
		},
		$html
	);

	return is_string( $rewritten ) ? $rewritten : $html;
}
add_filter( 'render_block', 'videolab_content_rewrite_root_hrefs', 9 );

/**
 * Rewrites stored navigation and button URLs before they become hrefs.
 *
 * @param array<string,mixed> $parsed Parsed block.
 * @return array<string,mixed>
 */
function videolab_content_rewrite_block_urls( $parsed ) {
	$name = $parsed['blockName'] ?? '';
	if ( ! in_array( $name, array( 'core/navigation-link', 'core/button' ), true ) ) {
		return $parsed;
	}
	if ( ! empty( $parsed['attrs']['url'] ) ) {
		$parsed['attrs']['url'] = videolab_content_public_url( (string) $parsed['attrs']['url'] );
	}
	return $parsed;
}
add_filter( 'render_block_data', 'videolab_content_rewrite_block_urls' );

/**
 * @param array<string,string> $atts Link attributes.
 * @return array<string,string>
 */
function videolab_content_nav_menu_link_attributes( $atts ) {
	if ( ! empty( $atts['href'] ) ) {
		$atts['href'] = videolab_content_public_url( $atts['href'] );
	}
	return $atts;
}
add_filter( 'nav_menu_link_attributes', 'videolab_content_nav_menu_link_attributes' );
