<?php
/**
 * Content, packages, price visibility and SEO for the 2026-09 editorial pass.
 *
 * @package VideoLabContent
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'VIDEOLAB_EDITORIAL_SEO_01', 'seo-01' );

/**
 * @return array<string,array<int,array<string,mixed>>>
 */
function videolab_content_service_packages() {
	return array(
		'monitoring' => array(
			array(
				'key'      => 'project-monitor',
				'title'    => 'Projekto dokumentavimas',
				'featured' => true,
				'lead'     => 'Vienam projekto taškui ir galutiniam filmui.',
				'points'   => array(
					'Vienas stebėjimo taškas',
					'Parengimas, diegimo koordinavimas, prieigos ir archyvas',
					'Nuotolinė sistemos ir vaizdų kontrolė',
					'60–90 sek. galutinis pagreitintos eigos filmas',
					'Du pataisymų etapai',
				),
			),
			array(
				'key'      => 'project-progress',
				'title'    => 'Projekto eiga ir komunikacija',
				'featured' => false,
				'lead'     => 'Projektui, kuriam reikia eigos klipų ir papildomų filmavimų.',
				'points'   => array(
					'Iki dviejų stebėjimo taškų ir pradinio paketo priežiūra',
					'Mėnesiniai 20–40 sek. progreso klipai',
					'Iki dviejų papildomų filmavimo dienų objekte',
					'Drono kadrai ir pasirinkti interviu',
					'90–150 sek. galutinis filmas, horizontalios ir vertikalios versijos',
					'Du pataisymų etapai',
				),
			),
			array(
				'key'      => 'project-story',
				'title'    => 'Visa projekto istorija',
				'featured' => false,
				'lead'     => 'Ilgam projektui su keliais taškais ir išsamesne istorija.',
				'points'   => array(
					'2–3 stebėjimo taškai',
					'Kasmėnesinis turinys ir ketvirtiniai filmavimai',
					'Svarbiausių etapų dokumentavimas, drono kadrai ir interviu',
					'2–4 min. galutinis filmas',
					'Trumpos versijos',
					'Iki trijų pataisymų etapų',
				),
			),
		),
		'periodic'   => array(
			array(
				'key'      => 'regular-content',
				'title'    => 'Reguliarus turinys',
				'featured' => true,
				'lead'     => 'Mėnesiniam ritmui su viena filmavimo diena.',
				'points'   => array(
					'Viena filmavimo diena per mėnesį',
					'Vienas pagrindinis klipas arba interviu',
					'5–8 trumpi klipai per mėnesį',
					'Horizontalios ir vertikalios versijos',
					'Subtitrai ir bazinė grafika',
					'Du pataisymų etapai',
				),
			),
			array(
				'key'      => 'content-growth',
				'title'    => 'Daugiau temų ir formatų',
				'featured' => false,
				'lead'     => 'Mėnesiniam ritmui su daugiau temų.',
				'points'   => array(
					'Iki dviejų filmavimo dienų per mėnesį',
					'Dvi pagrindinės temos',
					'Du pagrindiniai klipai arba interviu',
					'8–14 trumpų klipų per mėnesį',
					'Darbuotojų, projektų ir klientų istorijos',
					'Iki dviejų pataisymų etapų',
				),
			),
			array(
				'key'      => 'content-partner',
				'title'    => 'Išorinė vaizdo turinio komanda',
				'featured' => false,
				'lead'     => 'Komandai, kuriai reikia daugiau filmavimų ir kanalų.',
				'points'   => array(
					'Ketvirtinis planavimas',
					'Mėnesiniame variante iki trijų filmavimo dienų',
					'15–24 turinio vienetai per mėnesį',
					'Kampanijos ir interviu',
					'Versijos skirtingiems kanalams',
					'Prioritetinis planavimas',
				),
			),
		),
		'product'    => array(
			array(
				'key'      => 'product-visual',
				'title'    => 'Produkto pristatymas',
				'featured' => true,
				'lead'     => 'Vienam produktui ir trumpam pristatymui.',
				'points'   => array(
					'Vienas produktas',
					'Kūrybinė kryptis ir vaizdo planas',
					'Viena filmavimo diena',
					'15–30 sek. pagrindinis klipas',
					'Iki trijų trumpų adaptacijų, horizontalūs ir vertikalūs formatai',
					'Bazinė grafika, garso dizainas ir du pataisymų etapai',
				),
			),
			array(
				'key'      => 'product-campaign',
				'title'    => 'Produkto kampanija',
				'featured' => false,
				'lead'     => 'Produktui ar produktų linijai ir platesnei kampanijai.',
				'points'   => array(
					'Produktas arba produktų linija',
					'Kampanijos koncepcija',
					'30–60 sek. pagrindinis filmas',
					'6–10 trumpesnių adaptacijų',
					'Realus filmavimas ir DI papildytos aplinkos pagal idėją',
					'Grafika, garsas, spalvos ir iki trijų pataisymų etapų',
				),
			),
			array(
				'key'      => 'product-launch',
				'title'    => 'Naujo produkto pristatymo kampanija',
				'featured' => false,
				'lead'     => 'Naujo produkto pristatymui keliais etapais.',
				'points'   => array(
					'Išplėtota idėja ir scenarijus',
					'Keli komunikacijos etapai',
					'Pagrindinis filmas',
					'10–20 adaptacijų',
					'Pagal sumanymą DI arba 3D aplinkos',
					'Iki trijų pataisymų etapų',
				),
			),
		),
	);
}

/**
 * @return array<string,array<string,string>>
 */
function videolab_content_service_copy() {
	return array(
		'monitoring' => array(
			'title'    => 'Projektų stebėsena ir „timelapse“',
			'excerpt'  => 'Projekto eiga, vaizdų archyvas ir galutinis filmas.',
			'scope'    => 'Fiksuojame, kaip auga ir keičiasi jūsų projektas. Pasirūpiname ilgalaikio fotografavimo organizavimu, gaunamų vaizdų priežiūra ir archyvu. Iš sukauptos medžiagos kuriame pagreitintos eigos filmą, o prireikus — ir tarpines projekto apžvalgas.',
			'exclusions' => 'Įrangos, prenumeratos, ryšio, montavimo ir kitų trečiųjų šalių sąnaudos apmokamos atskirai. Tai nėra apsaugos ar statybų techninės priežiūros paslauga. Tiesioginės peržiūros ir analizės galimybes aptariame pagal pasirinktos įrangos bei platformos funkcijas.',
			'cta'      => 'Plačiau apie projektų stebėseną',
			'seo_title'=> 'Statybų stebėsena ir timelapse | Video Lab',
			'seo_desc' => 'Ilgalaikė projektų stebėsena, vaizdų archyvas ir pagreitintos eigos filmas. Aptarkime, kaip fiksuoti jūsų statybų eigą.',
			'note'     => 'Pradinė kaina nurodyta be PVM. Įrangos, prenumeratos, ryšio ir montavimo sąnaudos derinamos atskirai.',
		),
		'periodic'   => array(
			'title'    => 'Reguliarus vaizdo turinys įmonėms',
			'excerpt'  => 'Jūsų žmonės, darbai ir patirtis — turinys komunikacijai.',
			'scope'    => 'Jūsų žmonės, patirtis ir kasdieniai darbai gali tapti įdomiu turiniu klientams, partneriams bei būsimiems darbuotojams. Kartu suplanuojame temas, filmuojame ir paruošiame klipus pasirinktiems kanalams. Dirbame kas mėnesį, kas ketvirtį ar kitu sutartu ritmu.',
			'exclusions' => 'Kiekių pavyzdžiai priklauso mėnesiniam paketų variantui. Mėnesiniam bendradarbiavimui taikomas trijų mėnesių minimalus įsipareigojimas. Filmavimų dažnumą, darbų apimtį ir kainą suderiname pagal jūsų poreikius. Reklamos biudžetas, administravimas ir publikavimas kliento kanaluose neįskaičiuoti, jei nesutarta kitaip.',
			'cta'      => 'Plačiau apie turinį įmonėms',
			'seo_title'=> 'Reguliarus vaizdo turinys įmonėms | Video Lab',
			'seo_desc' => 'Reguliarus įmonės vaizdo turinys: planavimas, filmavimai ir klipai komunikacijai. Dirbame kas mėnesį, kas ketvirtį ar kitu sutartu ritmu.',
			'note'     => 'Pradinė kaina nurodyta be PVM už mėnesinį modelį. Kitam ritmui apimtis ir kaina derinamos atskirai.',
		),
		'product'    => array(
			'title'    => 'Produktų filmavimas ir reklaminiai klipai',
			'excerpt'  => 'Nuo produkto pristatymo iki reklaminės kampanijos.',
			'scope'    => 'Parodome produkto išvaizdą, detales ir naudojimą. Nuo aiškaus pristatymo iki kūrybinės kampanijos — parengiame idėją, filmuojame ir sukuriame reikalingas klipo versijas. Kai idėjai tinka, filmuotą vaizdą papildome dirbtiniu intelektu sukurtomis aplinkomis ar efektais.',
			'exclusions' => 'Papildomos studijos, aktorių, specializuotų 3D / VFX ir kitų tiekėjų sąnaudos derinamos atskirai. DI naudojimą parenkame pagal kūrybinę idėją. Galutinė kaina priklauso nuo filmavimo, efektų ir reikalingų klipo versijų apimties.',
			'cta'      => 'Plačiau apie produktų klipus',
			'seo_title'=> 'Produktų filmavimas ir reklaminiai klipai | Video Lab',
			'seo_desc' => 'Produkto pristatymas ir reklaminiai klipai: idėja, filmavimas ir reikalingos klipo versijos. Aptarkime jūsų produkto vaizdą.',
			'note'     => 'Pradinė kaina nurodyta be PVM. Papildomų tiekėjų sąnaudos derinamos atskirai.',
		),
	);
}

function videolab_content_show_home_prices() {
	return '0' !== (string) get_option( 'videolab_show_home_prices', '1' );
}

function videolab_content_show_service_price( $post_id ) {
	return '1' === (string) get_post_meta( $post_id, 'videolab_show_price', true );
}

function videolab_content_service_permalink( $key ) {
	$pages = get_posts(
		array(
			'post_type'      => 'page',
			'post_status'    => array( 'publish', 'draft', 'private' ),
			'posts_per_page' => 1,
			'meta_key'       => 'videolab_service_key',
			'meta_value'     => $key,
			'fields'         => 'ids',
		)
	);
	return $pages ? get_permalink( (int) $pages[0] ) : videolab_content_public_url( '/#paslaugos' );
}

function videolab_content_p( $text ) {
	return '<!-- wp:paragraph --><p>' . esc_html( $text ) . '</p><!-- /wp:paragraph -->';
}

function videolab_content_h2( $text ) {
	return '<!-- wp:heading --><h2 class="wp-block-heading">' . esc_html( $text ) . '</h2><!-- /wp:heading -->';
}

function videolab_content_h3( $text ) {
	return '<!-- wp:heading {"level":3} --><h3 class="wp-block-heading">' . esc_html( $text ) . '</h3><!-- /wp:heading -->';
}

function videolab_content_faq( $summary, $answer ) {
	return '<!-- wp:details --><details class="wp-block-details"><summary>' . esc_html( $summary ) . '</summary>' . videolab_content_p( $answer ) . '</details><!-- /wp:details -->';
}

function videolab_content_service_page_content( $key ) {
	$contact = '/#kontaktai';
	$blocks  = '';

	if ( 'monitoring' === $key ) {
		$blocks .= videolab_content_service_media_block( 'monitoring' );
		$blocks .= videolab_content_p( 'Nuosekliai fiksuojami vaizdai leidžia peržiūrėti ankstesnius etapus, parodyti darbų eigą ir išsaugoti tai, ko vėliau nufilmuoti nebebus galima.' );
		$blocks .= videolab_content_h2( 'Kam tai tinka' );
		$blocks .= videolab_content_p( 'Statybų ir infrastruktūros projektams, kuriems svarbu išsaugoti eigą, dalintis progresu ir turėti galutinį pagreitintos eigos filmą.' );
		$blocks .= videolab_content_h2( 'Kaip peržiūrite eigą' );
		$blocks .= videolab_content_p( 'Nuotolinėje peržiūroje matote naujausius persiųstus kadrus ir ankstesnius etapus. Kaip dažnai vaizdai atsinaujina, priklauso nuo sutartos įrangos ir ryšio.' );
		$blocks .= videolab_content_h2( 'Prieigos' );
		$blocks .= videolab_content_p( 'Suderiname, kas gali matyti vaizdus, ir atskiriame vidinę peržiūrą nuo to, ką galima viešinti.' );
		$blocks .= videolab_content_h2( 'Archyvas' );
		$blocks .= videolab_content_p( 'Kaupiame projekto vaizdų archyvą, kad vėliau būtų galima peržiūrėti eigą ir paruošti sutartą filmą. Prireikus galima sulieti žmonių atvaizdus ar užmaskuoti jautrias zonas — tai suderiname prieš pradedant kaupti vaizdus.' );
		$blocks .= videolab_content_h2( 'Koks rezultatas' );
		$blocks .= videolab_content_p( 'Vaizdų archyvas, prižiūrima sistema ir sutartas galutinis filmas. Papildomi filmavimai, drono kadrai bei interviu gali papildyti galutinį filmą.' );
		$blocks .= '<!-- wp:videolab/service-packages {"serviceKey":"monitoring"} /-->';
		$blocks .= videolab_content_p( 'Paslaugos darbų apimtis ir trečiųjų šalių sąnaudos yra atskiros. Įrangos, prenumeratos, ryšio ir montavimo sąnaudos derinamos atskirai.' );
		$blocks .= videolab_content_h2( 'Kaip dirbame' );
		$blocks .= videolab_content_p( 'Suderiname taškus, prieigas ir kuriamą turinį. Stebime sistemą ir archyvą viso projekto metu, tada montuojame sutartą filmą.' );
		$blocks .= '<!-- wp:videolab/related-works {"serviceKey":"monitoring"} /-->';
		$blocks .= videolab_content_h2( 'Svarbios sąlygos' );
		$blocks .= videolab_content_p( 'Tai nėra apsaugos ar techninės priežiūros paslauga. Tiesioginės peržiūros ir analizės galimybes aptariame pagal pasirinktos įrangos bei platformos funkcijas. Jos nėra standartinė kiekvieno paketo dalis.' );
		$blocks .= videolab_content_h2( 'Dažni klausimai' );
		$blocks .= videolab_content_faq( 'Ar kaina apima kameras ir montavimą?', 'Ne. Įrangos, prenumeratos, ryšio ir montavimo sąnaudos derinamos atskirai.' );
		$blocks .= videolab_content_faq( 'Ar tai apsaugos kamera?', 'Ne. Fiksuojame projekto eigą komunikacijai ir istorijai, ne saugumui.' );
		$blocks .= videolab_content_faq( 'Ar tiesioginė peržiūra įskaičiuota?', 'Tiesioginės peržiūros ir analizės galimybes aptariame pagal pasirinktos įrangos bei platformos funkcijas. Jos nėra standartinė kiekvieno paketo dalis.' );
		$blocks .= videolab_content_faq( 'Kiek trunka galutinis filmas?', 'Pradiniame pakete — 60–90 sekundžių. Didesniuose paketuose filmas ilgesnis, pagal pasiūlymą.' );
	} elseif ( 'periodic' === $key ) {
		$blocks .= videolab_content_p( 'Kartu suplanuojame temas, filmuojame ir paruošiame klipus pasirinktiems kanalams. Dirbame kas mėnesį, kas ketvirtį ar kitu sutartu ritmu.' );
		$blocks .= videolab_content_h2( 'Kam tai tinka' );
		$blocks .= videolab_content_p( 'Įmonėms, kurioms reikia nuoseklaus vaizdo turinio apie žmones, darbus ir patirtį — klientams, partneriams ar būsimiems darbuotojams.' );
		$blocks .= videolab_content_h2( 'Koks rezultatas' );
		$blocks .= videolab_content_p( 'Sutarti klipai ir adaptacijos jūsų kanalams. Žemiau nurodyti kiekiai priklauso mėnesiniam paketų variantui.' );
		$blocks .= '<!-- wp:videolab/service-packages {"serviceKey":"periodic"} /-->';
		$blocks .= videolab_content_p( 'Galima dirbti kas mėnesį, kas ketvirtį ar kitu sutartu ritmu. Mėnesiniam bendradarbiavimui taikomas trijų mėnesių minimalus įsipareigojimas. Filmavimų dažnumą, darbų apimtį ir kainą suderiname pagal jūsų poreikius.' );
		$blocks .= videolab_content_h2( 'Kaip dirbame' );
		$blocks .= videolab_content_p( 'Suplanuojame temas, filmuojame sutartu ritmu ir paruošiame versijas. Jei bendradarbiaujame reguliariai, kartu planuojame kitus filmavimus.' );
		$blocks .= '<!-- wp:videolab/related-works {"serviceKey":"periodic"} /-->';
		$blocks .= videolab_content_h2( 'Svarbios sąlygos' );
		$blocks .= videolab_content_p( 'Reklamos biudžetas, administravimas ir publikavimas kliento kanaluose neįskaičiuoti, jei nesutarta kitaip.' );
		$blocks .= videolab_content_h2( 'Dažni klausimai' );
		$blocks .= videolab_content_faq( 'Ar visada filmuojate kas mėnesį?', 'Ne. Galime dirbti kas mėnesį, kas ketvirtį ar kitu sutartu ritmu.' );
		$blocks .= videolab_content_faq( 'Ar galime filmuoti kartą per ketvirtį?', 'Taip. Filmavimų dažnumą ir turinio kiekį suderiname pagal jūsų komunikacijos planą. Tokio bendradarbiavimo kainą pateikiame individualiai.' );
		$blocks .= videolab_content_faq( 'Ar turite minimalų terminą?', 'Trijų mėnesių minimalus įsipareigojimas taikomas tik mėnesiniam modeliui.' );
		$blocks .= videolab_content_faq( 'Ar publikuojate turinį mūsų kanaluose?', 'Publikavimas ir reklamos administravimas neįskaičiuoti, jei nesutarta kitaip.' );
	} else {
		$blocks .= videolab_content_p( 'Parodome produkto išvaizdą, detales ir naudojimą. Nuo aiškaus pristatymo iki kūrybinės kampanijos — parengiame idėją, filmuojame ir sukuriame reikalingas klipo versijas.' );
		$blocks .= videolab_content_h2( 'Kam tai tinka' );
		$blocks .= videolab_content_p( 'Gamintojams ir prekių ženklams, pristatantiems savo produktus ar ruošiantiems reklaminę kampaniją.' );
		$blocks .= videolab_content_h2( 'Koks rezultatas' );
		$blocks .= videolab_content_p( 'Pagrindinis klipas ir sutartos adaptacijos. Kai idėjai tinka, filmuotą vaizdą papildome dirbtiniu intelektu sukurtomis aplinkomis ar efektais.' );
		$blocks .= '<!-- wp:videolab/service-packages {"serviceKey":"product"} /-->';
		$blocks .= videolab_content_p( 'Papildomos studijos, aktorių, 3D / VFX ir kitų tiekėjų sąnaudos derinamos atskirai.' );
		$blocks .= videolab_content_h2( 'Kaip dirbame' );
		$blocks .= videolab_content_p( 'Suderiname kūrybinę kryptį, filmuojame ir paruošiame sutartas versijas.' );
		$blocks .= '<!-- wp:videolab/related-works {"serviceKey":"product"} /-->';
		$blocks .= videolab_content_h2( 'Svarbios sąlygos' );
		$blocks .= videolab_content_p( 'Kūrybinio darbo apimtis ir papildomų tiekėjų sąnaudos yra atskiros.' );
		$blocks .= videolab_content_h2( 'Dažni klausimai' );
		$blocks .= videolab_content_faq( 'Kaip DI veikia kainą?', 'DI naudojimą parenkame pagal kūrybinę idėją. Galutinė kaina priklauso nuo filmavimo, efektų ir reikalingų klipo versijų apimties.' );
		$blocks .= videolab_content_faq( 'Ar filmuojate kelis produktus?', 'Pradiniame pakete — vienas produktas. Linija ir kampanija priklauso didesniems paketams.' );
		$blocks .= videolab_content_faq( 'Ar studija ir aktoriai įskaičiuoti?', 'Ne. Tokios sąnaudos derinamos atskirai.' );
		$blocks .= videolab_content_faq( 'Kokie formatai gaunami?', 'Horizontalūs ir vertikalūs formatai pagal sutartą paketą.' );
	}

	$blocks .= videolab_content_h2( 'Aptarkime jūsų projektą' );
	$blocks .= '<!-- wp:paragraph --><p><a class="vl-text-link" href="' . esc_url( $contact ) . '">Aptarkime projektą <span class="vl-arrow" aria-hidden="true"></span></a></p><!-- /wp:paragraph -->';
	$blocks .= videolab_content_p( 'Tai svetainės peržiūros versija. Užklausos forma dar neveikia.' );

	return $blocks;
}

function videolab_content_seed_home_content_seo_01( $media ) {
	$hero_alt   = (string) get_post_meta( $media['hero'], '_wp_attachment_image_alt', true );
	$hero_attrs = wp_json_encode(
		array(
			'align'         => 'full',
			'imageId'       => (int) $media['hero'],
			'videoId'       => 0,
			'mobileVideoId' => 0,
			'focalPoint'    => array(
				'x' => 0.56,
				'y' => 0.67,
			),
			'alt'           => $hero_alt,
			'ctaText'       => __( 'Aptarkime projektą', 'videolab-content' ),
			'ctaUrl'        => '#kontaktai',
		),
		JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
	);

	$works = get_post_type_archive_link( 'work' );
	$works = $works ? $works : videolab_content_public_url( '/darbai/' );
	$contact = videolab_content_public_url( '/#kontaktai' );

	return sprintf(
		'<!-- wp:group {"align":"wide","className":"vl-intro","layout":{"type":"default"}} -->
		<div class="wp-block-group alignwide vl-intro">
			<!-- wp:paragraph {"className":"vl-eyebrow"} --><p class="vl-eyebrow">VIDEO LAB / VIZUALINIO TURINIO PARTNERIS</p><!-- /wp:paragraph -->
			<!-- wp:group {"className":"vl-intro-grid","layout":{"type":"default"}} --><div class="wp-block-group vl-intro-grid">
				<!-- wp:heading {"level":1} --><h1 class="wp-block-heading">Filmuojame projektų eigą, įmonių gyvenimą ir produktus.</h1><!-- /wp:heading -->
				<!-- wp:paragraph {"className":"vl-position"} --><p class="vl-position">Nuo pirmųjų statybų dienų iki produkto pristatymo. Planuojame filmavimus, fiksuojame svarbiausius momentus ir kuriame vaizdo turinį, kurį galite naudoti pristatymuose, reklamoje bei kasdienėje komunikacijoje.</p><!-- /wp:paragraph -->
			</div><!-- /wp:group -->
			<!-- wp:paragraph {"className":"vl-intro-actions"} --><p class="vl-intro-actions"><a class="vl-text-link" href="%4$s">Aptarkime projektą</a> <a class="vl-text-link" href="%5$s">Peržiūrėti darbus</a></p><!-- /wp:paragraph -->
		</div><!-- /wp:group -->

		<!-- wp:videolab/hero-media %1$s /-->

		<!-- wp:group {"anchor":"paslaugos","align":"wide","className":"vl-services","layout":{"type":"default"}} --><div id="paslaugos" class="wp-block-group alignwide vl-services">
			<!-- wp:group {"className":"vl-section-heading","layout":{"type":"default"}} --><div class="wp-block-group vl-section-heading">
				<!-- wp:heading --><h2 class="wp-block-heading">Ką galime sukurti kartu?</h2><!-- /wp:heading -->
			</div><!-- /wp:group -->
			<!-- wp:videolab/service-prices /-->
		</div><!-- /wp:group -->

		<!-- wp:group {"anchor":"darbai","align":"wide","className":"vl-work","layout":{"type":"default"}} --><div id="darbai" class="wp-block-group alignwide vl-work">
			<!-- wp:group {"className":"vl-section-heading","layout":{"type":"default"}} --><div class="wp-block-group vl-section-heading">
				<!-- wp:heading --><h2 class="wp-block-heading">Susipažinkite per mūsų darbus.</h2><!-- /wp:heading -->
				<!-- wp:paragraph {"className":"vl-muted"} --><p class="vl-muted">Projektų kadrai ir kūrybinės koncepcijos.</p><!-- /wp:paragraph -->
			</div><!-- /wp:group -->
			<!-- wp:videolab/work-grid %6$s /-->
			<!-- wp:paragraph --><p><a class="vl-text-link" href="%5$s">Peržiūrėti visus darbus <span class="vl-arrow" aria-hidden="true"></span></a></p><!-- /wp:paragraph -->
		</div><!-- /wp:group -->

		<!-- wp:group {"anchor":"stebesena","align":"full","className":"vl-monitor","layout":{"type":"constrained"}} --><div id="stebesena" class="wp-block-group alignfull vl-monitor">
			<!-- wp:group {"align":"wide","className":"vl-monitor-grid","layout":{"type":"default"}} --><div class="wp-block-group alignwide vl-monitor-grid">
				<!-- wp:group {"className":"vl-monitor-copy","layout":{"type":"default"}} --><div class="wp-block-group vl-monitor-copy">
					<!-- wp:paragraph {"className":"vl-eyebrow"} --><p class="vl-eyebrow">PROJEKTŲ STEBĖSENA</p><!-- /wp:paragraph -->
					<!-- wp:heading --><h2 class="wp-block-heading">Mėnesiai darbo. Išsaugota projekto istorija.</h2><!-- /wp:heading -->
					<!-- wp:paragraph --><p>Statybos keičiasi kasdien. Nuosekliai fiksuojami vaizdai leidžia peržiūrėti ankstesnius etapus, parodyti darbų eigą ir išsaugoti tai, ko vėliau nufilmuoti nebebus galima.</p><!-- /wp:paragraph -->
					<!-- wp:paragraph --><p>Naudojame specializuotą ilgalaikio fotografavimo įrangą ir nuotolinės peržiūros platformą. Pagal projekto poreikius parenkame fotografavimo taškus, suderiname prieigas ir kuriamą turinį. Prižiūrime gaunamus vaizdus ir kaupiame projekto archyvą. Papildomi filmavimai, drono kadrai bei interviu gali papildyti galutinį filmą.</p><!-- /wp:paragraph -->
					<!-- wp:paragraph {"className":"vl-muted"} --><p class="vl-muted">To paties objekto vaizdas dieną ir vakare. Pateikti kadrai skirti palyginimui — tai nėra tiesioginė projekto peržiūra.</p><!-- /wp:paragraph -->
					<!-- wp:paragraph --><p><a class="vl-text-link" href="%4$s">Aptarkime jūsų projektą <span class="vl-arrow" aria-hidden="true"></span></a></p><!-- /wp:paragraph -->
				</div><!-- /wp:group -->
				<!-- wp:videolab/image-comparison {"dayId":%3$d,"eveningId":%2$d,"dayLabel":"DIENA","eveningLabel":"VAKARAS"} /-->
			</div><!-- /wp:group -->
		</div><!-- /wp:group -->

		<!-- wp:group {"anchor":"apie","align":"wide","className":"vl-about","layout":{"type":"default"}} --><div id="apie" class="wp-block-group alignwide vl-about">
			<!-- wp:group {"layout":{"type":"default"}} --><div class="wp-block-group">
				<!-- wp:paragraph {"className":"vl-eyebrow"} --><p class="vl-eyebrow">KAIP DIRBAME</p><!-- /wp:paragraph -->
				<!-- wp:heading --><h2 class="wp-block-heading">Aiškus planas. Sklandus darbas.</h2><!-- /wp:heading -->
			</div><!-- /wp:group -->
			<!-- wp:group {"className":"vl-about-copy","layout":{"type":"default"}} --><div class="wp-block-group vl-about-copy">
				<!-- wp:paragraph --><p>Iš anksto sutariame, ką sukursime, kada pateiksime ir kiek tai kainuos. Projekto eigą koordinuoja jūsų kontaktinis asmuo, o filmavimo ir kūrybos specialistus pasitelkiame pagal darbų apimtį.</p><!-- /wp:paragraph -->
				<!-- wp:list {"ordered":true,"className":"vl-steps"} --><ol class="wp-block-list vl-steps"><li><span>01</span><div><h3>Išsiaiškiname, ko reikia.</h3><p>Aptariame, ką norite parodyti, kam skirtas turinys ir kur jį naudosite.</p></div></li><li><span>02</span><div><h3>Sutariame dėl darbų.</h3><p>Suderiname kūrybinę kryptį, filmavimus, galutinius formatus, terminus ir biudžetą.</p></div></li><li><span>03</span><div><h3>Paruošiame naudoti.</h3><p>Filmuojame, montuojame ir pateikiame sutartas versijas. Jei bendradarbiaujame reguliariai, kartu planuojame kitus filmavimus.</p></div></li></ol><!-- /wp:list -->
			</div><!-- /wp:group -->
		</div><!-- /wp:group -->

		<!-- wp:group {"anchor":"kontaktai","align":"full","className":"vl-contact","layout":{"type":"constrained"}} --><div id="kontaktai" class="wp-block-group alignfull vl-contact">
			<!-- wp:group {"align":"wide","layout":{"type":"default"}} --><div class="wp-block-group alignwide">
				<!-- wp:paragraph {"className":"vl-eyebrow"} --><p class="vl-eyebrow">KONTAKTAI</p><!-- /wp:paragraph -->
				<!-- wp:group {"className":"vl-contact-grid","layout":{"type":"default"}} --><div class="wp-block-group alignwide vl-contact-grid">
					<!-- wp:heading --><h2 class="wp-block-heading">Papasakokite, ką planuojate.</h2><!-- /wp:heading -->
					<!-- wp:group {"layout":{"type":"default"}} --><div class="wp-block-group">
						<!-- wp:paragraph --><p>Pradedate statybas, ieškote nuolatinio filmavimo partnerio ar ruošiate produkto pristatymą?</p><!-- /wp:paragraph -->
						<!-- wp:paragraph --><p>Trumpai aprašykite sumanymą ir numatomą laiką. Jei jau žinote, kur naudosite turinį ir kokį biudžetą planuojate, parašykite ir tai.</p><!-- /wp:paragraph -->
						<!-- wp:paragraph {"className":"vl-contact-note"} --><p class="vl-contact-note">Tai svetainės peržiūros versija. Užklausos forma dar neveikia.</p><!-- /wp:paragraph -->
					</div><!-- /wp:group -->
				</div><!-- /wp:group -->
			</div><!-- /wp:group -->
		</div><!-- /wp:group -->',
		$hero_attrs,
		! empty( $media['evening'] ) ? (int) $media['evening'] : (int) $media['hero'],
		(int) $media['day'],
		esc_url( $contact ),
		esc_url( $works ),
		wp_json_encode(
			array(
				'note'            => '',
				'replacementNote' => 'Atrinkti projektai — nuo įmonių ir produktų pristatymų iki reklamos bei statybų eigos filmų.',
			),
			JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
		)
	);
}

function videolab_content_render_service_packages( $attributes = array() ) {
	$key      = videolab_content_sanitize_service_key( $attributes['serviceKey'] ?? '' );
	$packages = videolab_content_service_packages();
	if ( ! $key || empty( $packages[ $key ] ) ) {
		return '';
	}

	$page_id = get_the_ID();
	$output  = '<div class="vl-packages">';
	if ( $page_id && videolab_content_show_service_price( $page_id ) ) {
		$price  = (int) get_post_meta( $page_id, 'videolab_starting_price_eur', true );
		$period = (string) get_post_meta( $page_id, 'videolab_price_period', true );
		if ( $price ) {
			$output .= videolab_content_public_price_html( $price, $period, $key );
		}
	}
	$output .= '<h2 class="vl-packages__title">' . esc_html__( 'Paketai', 'videolab-content' ) . '</h2><div class="vl-packages__grid">';
	foreach ( $packages[ $key ] as $package ) {
		$classes = 'vl-package';
		if ( ! empty( $package['featured'] ) ) {
			$classes .= ' vl-package--featured';
		}
		$output .= '<article class="' . esc_attr( $classes ) . '">';
		if ( ! empty( $package['featured'] ) ) {
			$output .= '<p class="vl-package__flag">' . esc_html__( 'Pradinis paketas', 'videolab-content' ) . '</p>';
		}
		$output .= '<h3>' . esc_html( $package['title'] ) . '</h3>';
		if ( ! empty( $package['lead'] ) ) {
			$output .= '<p class="vl-package__lead">' . esc_html( $package['lead'] ) . '</p>';
		}
		if ( ! empty( $package['points'] ) && is_array( $package['points'] ) ) {
			$output .= '<ul>';
			foreach ( $package['points'] as $point ) {
				$output .= '<li>' . esc_html( $point ) . '</li>';
			}
			$output .= '</ul>';
		} elseif ( ! empty( $package['body'] ) ) {
			$output .= '<p>' . esc_html( $package['body'] ) . '</p>';
		}
		if ( empty( $package['featured'] ) ) {
			$output .= '<p class="vl-package__offer">' . esc_html__( 'Kaina pateikiama individualiame pasiūlyme.', 'videolab-content' ) . '</p>';
		}
		$output .= '</article>';
	}
	return $output . '</div></div>';
}

function videolab_content_service_media_block( $key ) {
	if ( 'monitoring' !== $key ) {
		return '';
	}
	$id = 0;
	foreach ( array( 'media:build.webp', 'media:build.jpeg', 'media:day.webp', 'media:day.jpeg' ) as $seed_key ) {
		$id = (int) videolab_content_seed_find_post( $seed_key, 'attachment' );
		if ( $id ) {
			break;
		}
	}
	if ( ! $id ) {
		return '';
	}
	return '<!-- wp:videolab/service-media ' . wp_json_encode( array( 'imageId' => $id ), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . ' /-->';
}

function videolab_content_render_service_media( $attributes = array() ) {
	$image_id  = absint( $attributes['imageId'] ?? 0 );
	$video_url = esc_url( (string) ( $attributes['videoUrl'] ?? '' ) );
	if ( ! $image_id && ! $video_url ) {
		return '';
	}

	$output = '<figure class="vl-service-media">';
	if ( $image_id ) {
		$output .= wp_get_attachment_image(
			$image_id,
			'large',
			false,
			array(
				'loading' => 'lazy',
				'alt'     => (string) get_post_meta( $image_id, '_wp_attachment_image_alt', true ),
			)
		);
	}
	if ( $video_url ) {
		$output .= '<a class="vl-text-link" href="' . esc_url( $video_url ) . '" rel="noopener noreferrer">' . esc_html__( 'Žiūrėti video', 'videolab-content' ) . '</a>';
	}
	return $output . '</figure>';
}

function videolab_content_render_related_works( $attributes = array() ) {
	$key  = videolab_content_sanitize_service_key( $attributes['serviceKey'] ?? '' );
	$map  = array(
		'monitoring' => 'stebesena',
		'periodic'   => 'periodinis-turinys',
		'product'    => 'produkto-video',
	);
	$term = $map[ $key ] ?? '';
	if ( ! $term ) {
		return '';
	}

	$works = get_posts(
		array(
			'post_type'      => 'work',
			'post_status'    => 'publish',
			'posts_per_page' => 3,
			'tax_query'      => array(
				array(
					'taxonomy' => 'work_service',
					'field'    => 'slug',
					'terms'    => $term,
				),
			),
		)
	);
	if ( ! $works ) {
		return '';
	}

	$output = '<div class="vl-related"><h2>' . esc_html__( 'Susiję darbai', 'videolab-content' ) . '</h2><div class="vl-related__grid">';
	foreach ( $works as $work ) {
		$origin = get_post_meta( $work->ID, 'videolab_origin', true );
		$image  = get_the_post_thumbnail( $work, 'videolab-card', array( 'loading' => 'lazy' ) );
		$output .= '<a class="vl-related__card" href="' . esc_url( get_permalink( $work ) ) . '">';
		if ( $image ) {
			$output .= $image;
		}
		if ( 'ai_concept' === $origin ) {
			$output .= '<span class="vl-badge">' . esc_html__( 'DI KONCEPCIJA', 'videolab-content' ) . '</span>';
		}
		$output .= '<strong>' . esc_html( get_the_title( $work ) ) . '</strong></a>';
	}
	return $output . '</div></div>';
}

function videolab_content_default_work_note() {
	return __( 'Projektų kadrai ir kūrybinės koncepcijos.', 'videolab-content' );
}

function videolab_content_default_hero_cta() {
	return __( 'Aptarkime projektą', 'videolab-content' );
}

function videolab_content_document_title_parts( $parts ) {
	if ( is_front_page() ) {
		$title = get_post_meta( (int) get_option( 'page_on_front' ), 'videolab_seo_title', true );
		if ( $title ) {
			$parts['title']   = $title;
			$parts['site']    = '';
			$parts['tagline'] = '';
		}
		return $parts;
	}
	if ( is_page() ) {
		$title = get_post_meta( get_the_ID(), 'videolab_seo_title', true );
		if ( $title ) {
			$parts['title'] = $title;
			$parts['site']  = '';
		}
	}
	return $parts;
}
add_filter( 'document_title_parts', 'videolab_content_document_title_parts' );

function videolab_content_meta_description() {
	$description = '';
	if ( is_front_page() ) {
		$description = (string) get_post_meta( (int) get_option( 'page_on_front' ), 'videolab_seo_description', true );
	} elseif ( is_page() ) {
		$description = (string) get_post_meta( get_the_ID(), 'videolab_seo_description', true );
	}
	if ( '' === $description ) {
		return;
	}
	echo '<meta name="description" content="' . esc_attr( $description ) . '">' . "\n";
}
add_action( 'wp_head', 'videolab_content_meta_description', 1 );

function videolab_content_keep_noindex( $robots ) {
	$robots['noindex'] = true;
	$robots['nofollow'] = true;
	return $robots;
}
add_filter( 'wp_robots', 'videolab_content_keep_noindex', 99 );

function videolab_content_add_options_page() {
	add_options_page(
		__( 'Video Lab', 'videolab-content' ),
		__( 'Video Lab', 'videolab-content' ),
		'manage_options',
		'videolab-content',
		'videolab_content_render_options_page'
	);
}
add_action( 'admin_menu', 'videolab_content_add_options_page' );

function videolab_content_register_setting() {
	register_setting(
		'videolab_content',
		'videolab_show_home_prices',
		array(
			'type'              => 'string',
			'sanitize_callback' => static function ( $value ) {
				return $value ? '1' : '0';
			},
			'default'           => '1',
		)
	);
}
add_action( 'admin_init', 'videolab_content_register_setting' );

function videolab_content_render_options_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'Video Lab', 'videolab-content' ); ?></h1>
		<form action="options.php" method="post">
			<?php settings_fields( 'videolab_content' ); ?>
			<table class="form-table">
				<tr>
					<th scope="row"><?php esc_html_e( 'Pradžios kainos', 'videolab-content' ); ?></th>
					<td>
						<label>
							<input type="checkbox" name="videolab_show_home_prices" value="1" <?php checked( videolab_content_show_home_prices() ); ?>>
							<?php esc_html_e( 'Rodyti pradines kainas pradžios paslaugų sąraše', 'videolab-content' ); ?>
						</label>
						<p class="description"><?php esc_html_e( 'Kainų viešinimas dar nepatvirtintas. Paslėpus kainos nepatenka į HTML.', 'videolab-content' ); ?></p>
					</td>
				</tr>
			</table>
			<?php submit_button(); ?>
		</form>
	</div>
	<?php
}

/**
 * Applies editorial texts to known starter copy only.
 */
function videolab_content_apply_editorial_seo_01() {
	if ( VIDEOLAB_EDITORIAL_SEO_01 === get_option( 'videolab_editorial_version' ) ) {
		return;
	}

	if ( false === get_option( 'videolab_show_home_prices', false ) ) {
		update_option( 'videolab_show_home_prices', '1', false );
	}

	$copy = videolab_content_service_copy();
	$all  = videolab_content_service_packages();

	foreach ( $copy as $key => $data ) {
		$page_id = videolab_content_seed_find_post( 'service:' . $key, 'page' );
		if ( ! $page_id ) {
			continue;
		}

		$current = (string) get_post_field( 'post_content', $page_id );
		$starters = array(
			'Paslaugos puslapio turinys bus rengiamas 2 etape.',
			'Šis vietinis juodraštis yra numatyta išsamios v5',
		);
		$is_starter = false;
		foreach ( $starters as $needle ) {
			if ( false !== strpos( $current, $needle ) ) {
				$is_starter = true;
				break;
			}
		}

		$update = array(
			'ID'          => $page_id,
			'post_status' => 'publish',
			'post_name'   => get_post_field( 'post_name', $page_id ),
		);
		$title_now = get_the_title( $page_id );
		$old_titles = array(
			'Projektų stebėsena',
			'Periodinis turinys',
			'Produkto video',
			$data['title'],
		);
		if ( in_array( $title_now, $old_titles, true ) ) {
			$update['post_title'] = $data['title'];
		}
		$excerpt_now = (string) get_post_field( 'post_excerpt', $page_id );
		$old_excerpts = array(
			'Projekto eiga, archyvas ir galutinis filmas.',
			'Nuosekli įmonės komunikacija.',
			'Produkto pristatymas ir kampanijos.',
			$data['excerpt'],
		);
		if ( in_array( $excerpt_now, $old_excerpts, true ) ) {
			$update['post_excerpt'] = $data['excerpt'];
		}
		if ( $is_starter ) {
			$update['post_content'] = videolab_content_service_page_content( $key );
		}
		wp_update_post( wp_slash( $update ) );

		$meta_map = array(
			'videolab_scope'      => array( $data['scope'], 'Ilgalaikė vizualinė dokumentacija', 'Planavimas, periodiniai filmavimai', 'Nuo kūrybinės krypties' ),
			'videolab_exclusions' => array( $data['exclusions'], 'Konkreti įrangos', 'Filmavimų dažnis', 'AI, filmavimas, scenografija' ),
			'videolab_cta'        => array( $data['cta'], 'Plačiau apie stebėseną', 'Aptarti turinio sistemą', 'Aptarti produkto video' ),
			'videolab_price_note' => array( $data['note'] ),
		);
		foreach ( $meta_map as $meta_key => $values ) {
			$current_meta = (string) get_post_meta( $page_id, $meta_key, true );
			$replace      = false;
			if ( '' === $current_meta ) {
				$replace = true;
			} else {
				foreach ( $values as $known ) {
					if ( $current_meta === $known || 0 === strpos( $current_meta, $known ) ) {
						$replace = true;
						break;
					}
				}
			}
			if ( $replace ) {
				update_post_meta( $page_id, $meta_key, $values[0] );
			}
		}

		if ( ! get_post_meta( $page_id, 'videolab_packages', true ) ) {
			update_post_meta( $page_id, 'videolab_packages', wp_json_encode( $all[ $key ], JSON_UNESCAPED_UNICODE ) );
		}
		if ( '' === get_post_meta( $page_id, 'videolab_show_price', true ) ) {
			update_post_meta( $page_id, 'videolab_show_price', '0' );
		}
		if ( ! get_post_meta( $page_id, 'videolab_seo_title', true ) ) {
			update_post_meta( $page_id, 'videolab_seo_title', $data['seo_title'] );
		}
		if ( ! get_post_meta( $page_id, 'videolab_seo_description', true ) ) {
			update_post_meta( $page_id, 'videolab_seo_description', $data['seo_desc'] );
		}
	}

	$parent = videolab_content_seed_find_post( 'page:services', 'page' );
	if ( $parent && 'draft' === get_post_status( $parent ) ) {
		wp_update_post(
			array(
				'ID'          => $parent,
				'post_status' => 'publish',
				'post_content'=> videolab_content_p( 'Trys kryptys: projektų stebėsena, reguliarus turinys įmonėms ir produktų klipai.' ),
			)
		);
	}

	$home_id = videolab_content_seed_find_post( 'page:home', 'page' );
	if ( $home_id ) {
		$content = (string) get_post_field( 'post_content', $home_id );
		if ( false !== strpos( $content, 'vaizdas, kuris' ) || false !== strpos( $content, 'TRYS KRYPTYS. VIENAS PARTNERIS.' ) ) {
			$media = array(
				'hero' => 0,
				'day'  => 0,
			);
			if ( preg_match( '/<!-- wp:videolab\/hero-media\s+(\{.*?\})\s+\/-->/s', $content, $match ) ) {
				$attrs = json_decode( $match[1], true );
				if ( is_array( $attrs ) ) {
					$media['hero'] = absint( $attrs['imageId'] ?? 0 );
				}
			}
			if ( preg_match( '/"dayId":(\d+)/', $content, $match ) ) {
				$media['day'] = (int) $match[1];
			}
			$media['evening'] = 0;
			if ( preg_match( '/"eveningId":(\d+)/', $content, $match ) ) {
				$media['evening'] = (int) $match[1];
			}
			if ( ! $media['hero'] ) {
				$hero = videolab_content_seed_find_post( 'media:hero.webp', 'attachment' );
				if ( ! $hero ) {
					$hero = videolab_content_seed_find_post( 'media:hero.jpeg', 'attachment' );
				}
				$media['hero'] = $hero;
			}
			if ( ! $media['day'] ) {
				$day = videolab_content_seed_find_post( 'media:day.webp', 'attachment' );
				if ( ! $day ) {
					$day = videolab_content_seed_find_post( 'media:day.jpeg', 'attachment' );
				}
				$media['day'] = $day;
			}
			if ( $media['hero'] && $media['day'] ) {
				wp_update_post(
					wp_slash(
						array(
							'ID'           => $home_id,
							'post_content' => videolab_content_seed_home_content_seo_01( $media ),
							'post_excerpt' => 'Nuo pirmųjų statybų dienų iki produkto pristatymo. Planuojame filmavimus ir kuriame vaizdo turinį komunikacijai.',
						)
					)
				);
			}
		}
		if ( ! get_post_meta( $home_id, 'videolab_seo_title', true ) ) {
			update_post_meta( $home_id, 'videolab_seo_title', 'Video turinio kūrimas verslui | Video Lab' );
		}
		if ( ! get_post_meta( $home_id, 'videolab_seo_description', true ) ) {
			update_post_meta( $home_id, 'videolab_seo_description', 'Filmuojame projektų eigą, įmonių gyvenimą ir produktus. Planuojame filmavimus ir kuriame vaizdo turinį pristatymams, reklamai ir kasdienei komunikacijai.' );
		}
	}

	$terms = array(
		'stebesena'          => array( 'Projektų stebėsena', 'Projektų stebėsena' ),
		'periodinis-turinys' => array( 'Periodinis turinys', 'Reguliarus turinys' ),
		'produkto-video'     => array( 'Produkto video', 'Produktų klipai' ),
	);
	foreach ( $terms as $slug => $names ) {
		$term = get_term_by( 'slug', $slug, 'work_service' );
		if ( $term && ! is_wp_error( $term ) && $term->name === $names[0] ) {
			wp_update_term( (int) $term->term_id, 'work_service', array( 'name' => $names[1] ) );
		}
	}

	$nav_posts = get_posts(
		array(
			'post_type'      => array( 'wp_navigation', 'wp_template_part' ),
			'post_status'    => 'any',
			'posts_per_page' => -1,
		)
	);
	foreach ( $nav_posts as $nav ) {
		$content = (string) $nav->post_content;
		$updated = str_replace(
			array(
				'"label":"Aptarti projektą ↗"',
				'"label":"Aptarti projektą"',
			),
			'"label":"Kontaktai"',
			$content
		);
		if ( $updated !== $content ) {
			wp_update_post(
				array(
					'ID'           => $nav->ID,
					'post_content' => $updated,
				)
			);
		}
	}

	update_option( 'blog_public', 0, false );
	update_option( 'videolab_show_home_prices', get_option( 'videolab_show_home_prices', '1' ), false );
	flush_rewrite_rules( false );
	update_option( 'videolab_editorial_version', VIDEOLAB_EDITORIAL_SEO_01, false );
}
add_action( 'init', 'videolab_content_apply_editorial_seo_01', 110 );

/**
 * Removes the duplicated work-grid note when the section already has it.
 */
function videolab_content_apply_editorial_seo_01_note() {
	if ( 'seo-01-note-2' === get_option( 'videolab_editorial_note_version' ) ) {
		return;
	}
	$home_id = videolab_content_seed_find_post( 'page:home', 'page' );
	if ( $home_id ) {
		$content = (string) get_post_field( 'post_content', $home_id );
		$updated = str_replace(
			'"note":"Projektų kadrai ir kūrybinės koncepcijos."',
			'"note":""',
			$content
		);
		if ( $updated !== $content ) {
			wp_update_post(
				array(
					'ID'           => $home_id,
					'post_content' => $updated,
				)
			);
		}
	}
	update_option( 'videolab_editorial_note_version', 'seo-01-note-2', false );
}
add_action( 'init', 'videolab_content_apply_editorial_seo_01_note', 111 );

/**
 * Stored service links must stay root-relative so render time can apply home_url().
 */
function videolab_content_repair_relative_contact_links() {
	if ( 'relative' === get_option( 'videolab_contact_link_version' ) ) {
		return;
	}

	$posts = get_posts(
		array(
			'post_type'      => array( 'page', 'work', 'wp_template', 'wp_template_part', 'wp_navigation' ),
			'post_status'    => array( 'publish', 'draft', 'private' ),
			'posts_per_page' => -1,
		)
	);
	$from = array(
		'https://example.com:443/#kontaktai',
		'https://example.com/#kontaktai',
		'http://example.com/#kontaktai',
	);
	foreach ( $posts as $post ) {
		$next = str_replace( $from, '/#kontaktai', $post->post_content );
		if ( $next !== $post->post_content ) {
			wp_update_post(
				array(
					'ID'           => $post->ID,
					'post_content' => wp_slash( $next ),
				)
			);
		}
	}

	update_option( 'videolab_contact_link_version', 'relative', false );
}
add_action( 'init', 'videolab_content_repair_relative_contact_links', 113 );

/**
 * Replaces only the confirmed homepage work-section sentences.
 */
function videolab_content_apply_editorial_seo_03() {
	if ( 'seo-03' === get_option( 'videolab_editorial_version_03' ) ) {
		return;
	}

	$from = array(
		'Vienas atsakingas žmogus viso projekto metu.',
		'Nuo pirmo pokalbio iki paruoštos medžiagos bendraujate su vienu už jūsų projektą atsakingu žmogumi. Kai reikia, prisijungia papildomi filmavimo, garso, animacijos ar kitų sričių specialistai.',
	);
	$to   = array(
		'Aiškus planas. Sklandus darbas.',
		'Iš anksto sutariame, ką sukursime, kada pateiksime ir kiek tai kainuos. Projekto eigą koordinuoja jūsų kontaktinis asmuo, o filmavimo ir kūrybos specialistus pasitelkiame pagal darbų apimtį.',
	);
	$posts = get_posts(
		array(
			'post_type'      => array( 'page', 'wp_template', 'wp_template_part' ),
			'post_status'    => array( 'publish', 'draft', 'private' ),
			'posts_per_page' => -1,
		)
	);
	foreach ( $posts as $post ) {
		$updated = str_replace( $from, $to, (string) $post->post_content );
		if ( $updated !== $post->post_content ) {
			wp_update_post(
				array(
					'ID'           => $post->ID,
					'post_content' => wp_slash( $updated ),
				)
			);
		}
	}

	update_option( 'videolab_editorial_version_03', 'seo-03', false );
}
add_action( 'init', 'videolab_content_apply_editorial_seo_03', 114 );
