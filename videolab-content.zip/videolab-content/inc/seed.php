<?php
/**
 * Idempotent local starter content.
 *
 * The seed creates records only when its stable key does not exist. It never
 * updates an existing seeded post, so later editor changes remain untouched.
 *
 * @package VideoLabContent
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

register_activation_hook(
	VIDEOLAB_CONTENT_DIR . 'videolab-content.php',
	static function () {
		update_option( 'videolab_seed_pending', 1, false );
	}
);

/**
 * Runs after both the plugin and the Video Lab theme are active.
 */
function videolab_content_maybe_seed() {
	if ( get_option( 'videolab_seed_version' ) || 'videolab' !== get_stylesheet() ) {
		return;
	}

	$asset_dir = get_theme_file_path( 'assets/images' );
	if ( ! file_exists( $asset_dir . '/hero.jpeg' ) ) {
		return;
	}

	$result = videolab_content_seed_site( $asset_dir );
	if ( is_wp_error( $result ) ) {
		update_option( 'videolab_seed_error', $result->get_error_message(), false );
		return;
	}

	delete_option( 'videolab_seed_error' );
	delete_option( 'videolab_seed_pending' );
	update_option( 'videolab_seed_version', VIDEOLAB_CONTENT_VERSION, false );
}
add_action( 'init', 'videolab_content_maybe_seed', 99 );

/**
 * Imports one local theme image as a real WordPress attachment.
 */
function videolab_content_seed_attachment( $asset_dir, $filename, $alt ) {
	$existing = get_posts(
		array(
			'post_type'      => 'attachment',
			'post_status'    => 'inherit',
			'posts_per_page' => 1,
			'meta_key'       => '_videolab_seed_key',
			'meta_value'     => 'media:' . $filename,
			'fields'         => 'ids',
		)
	);
	if ( $existing ) {
		return (int) $existing[0];
	}

	$source = trailingslashit( $asset_dir ) . $filename;
	if ( ! file_exists( $source ) ) {
		return new WP_Error( 'videolab_missing_asset', sprintf( 'Nerastas temos failas: %s', $filename ) );
	}

	$uploads = wp_upload_dir();
	if ( ! empty( $uploads['error'] ) ) {
		return new WP_Error( 'videolab_upload_error', $uploads['error'] );
	}

	wp_mkdir_p( $uploads['path'] );
	$target_name = wp_unique_filename( $uploads['path'], wp_basename( $filename ) );
	$target      = trailingslashit( $uploads['path'] ) . $target_name;
	if ( ! copy( $source, $target ) ) {
		return new WP_Error( 'videolab_copy_error', sprintf( 'Nepavyko importuoti: %s', $filename ) );
	}

	$filetype      = wp_check_filetype( $target_name, null );
	$attachment_id = wp_insert_attachment(
		array(
			'guid'           => trailingslashit( $uploads['url'] ) . $target_name,
			'post_mime_type' => $filetype['type'],
			'post_title'     => sanitize_text_field( pathinfo( $target_name, PATHINFO_FILENAME ) ),
			'post_content'   => '',
			'post_status'    => 'inherit',
		),
		$target
	);

	if ( is_wp_error( $attachment_id ) ) {
		return $attachment_id;
	}

	require_once ABSPATH . 'wp-admin/includes/image.php';
	$metadata = wp_generate_attachment_metadata( $attachment_id, $target );
	if ( $metadata ) {
		wp_update_attachment_metadata( $attachment_id, $metadata );
	}
	update_post_meta( $attachment_id, '_wp_attachment_image_alt', sanitize_text_field( $alt ) );
	update_post_meta( $attachment_id, '_videolab_seed_key', 'media:' . $filename );
	update_post_meta( $attachment_id, '_videolab_media_origin', 'prototype-v5/ATIDARYTI.html' );

	return (int) $attachment_id;
}

function videolab_content_seed_find_post( $key, $post_type = 'any' ) {
	$posts = get_posts(
		array(
			'post_type'      => $post_type,
			'post_status'    => 'any',
			'posts_per_page' => 1,
			'meta_key'       => '_videolab_seed_key',
			'meta_value'     => $key,
			'fields'         => 'ids',
		)
	);
	return $posts ? (int) $posts[0] : 0;
}

function videolab_content_seed_insert_post( $key, $postarr ) {
	$existing = videolab_content_seed_find_post( $key, $postarr['post_type'] ?? 'any' );
	if ( $existing ) {
		return $existing;
	}
	$post_id = wp_insert_post( wp_slash( $postarr ), true );
	if ( ! is_wp_error( $post_id ) ) {
		update_post_meta( $post_id, '_videolab_seed_key', $key );
	}
	return $post_id;
}

function videolab_content_seed_image_block( $attachment_id, $size = 'large' ) {
	$url = wp_get_attachment_image_url( $attachment_id, $size );
	$alt = get_post_meta( $attachment_id, '_wp_attachment_image_alt', true );
	return sprintf(
		'<!-- wp:image {"id":%1$d,"sizeSlug":"%2$s","linkDestination":"none"} --><figure class="wp-block-image size-%2$s"><img src="%3$s" alt="%4$s" class="wp-image-%1$d"/></figure><!-- /wp:image -->',
		(int) $attachment_id,
		esc_attr( $size ),
		esc_url( $url ),
		esc_attr( $alt )
	);
}

function videolab_content_seed_gallery_block( $ids ) {
	$images = '';
	foreach ( $ids as $id ) {
		$images .= videolab_content_seed_image_block( $id );
	}
	return '<!-- wp:gallery {"linkTo":"none","sizeSlug":"large"} --><figure class="wp-block-gallery has-nested-images columns-default is-cropped">' . $images . '</figure><!-- /wp:gallery -->';
}

function videolab_content_seed_home_content( $media ) {
	$hero_alt   = (string) get_post_meta( $media['hero'], '_wp_attachment_image_alt', true );
	$hero_attrs = wp_json_encode(
		array(
			'align'         => 'full',
			'imageId'       => (int) $media['hero'],
			'videoId'       => 0,
			'mobileVideoId' => 0,
			'focalPoint'    => array(
				'x' => 0.56,
				'y' => 0.67,
			),
			'alt'           => $hero_alt,
			'ctaText'       => videolab_content_default_hero_cta(),
			'ctaUrl'        => '#stebesena',
		),
		JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
	);

	return sprintf(
		'<!-- wp:group {"align":"wide","className":"vl-intro","layout":{"type":"default"}} -->
		<div class="wp-block-group alignwide vl-intro">
			<!-- wp:paragraph {"className":"vl-eyebrow"} --><p class="vl-eyebrow">VIDEO LAB / VIZUALINIO TURINIO PARTNERIS</p><!-- /wp:paragraph -->
			<!-- wp:group {"className":"vl-intro-grid","layout":{"type":"default"}} --><div class="wp-block-group vl-intro-grid">
				<!-- wp:heading {"level":1} --><h1 class="wp-block-heading">vaizdas, kuris<br>kuria vertę.</h1><!-- /wp:heading -->
				<!-- wp:paragraph {"className":"vl-position"} --><p class="vl-position">Vizualinio turinio sistemos projektams, įmonėms ir produktams.</p><!-- /wp:paragraph -->
			</div><!-- /wp:group -->
		</div><!-- /wp:group -->

		<!-- wp:videolab/hero-media %1$s /-->

		<!-- wp:group {"anchor":"paslaugos","align":"wide","className":"vl-services","layout":{"type":"default"}} --><div id="paslaugos" class="wp-block-group alignwide vl-services">
			<!-- wp:group {"className":"vl-section-heading","layout":{"type":"default"}} --><div class="wp-block-group vl-section-heading">
				<!-- wp:paragraph {"className":"vl-eyebrow"} --><p class="vl-eyebrow">TRYS KRYPTYS. VIENAS PARTNERIS.</p><!-- /wp:paragraph -->
				<!-- wp:paragraph {"className":"vl-muted"} --><p class="vl-muted">Nuo sumanymo iki galutinio vaizdo</p><!-- /wp:paragraph -->
			</div><!-- /wp:group -->
			<!-- wp:videolab/service-prices /-->
		</div><!-- /wp:group -->

		<!-- wp:group {"anchor":"darbai","align":"wide","className":"vl-work","layout":{"type":"default"}} --><div id="darbai" class="wp-block-group alignwide vl-work">
			<!-- wp:group {"className":"vl-section-heading","layout":{"type":"default"}} --><div class="wp-block-group vl-section-heading">
				<!-- wp:heading --><h2 class="wp-block-heading">pirmiausia – vaizdas.</h2><!-- /wp:heading -->
				<!-- wp:paragraph {"className":"vl-muted"} --><p class="vl-muted">Projektų kadrai ir kūrybinės kryptys</p><!-- /wp:paragraph -->
			</div><!-- /wp:group -->
			<!-- wp:videolab/work-grid {"note":"AI koncepcijos aiškiai pažymėtos ir nėra pristatomos kaip klientų projektai."} /-->
		</div><!-- /wp:group -->

		<!-- wp:group {"anchor":"stebesena","align":"full","className":"vl-monitor","layout":{"type":"constrained"}} --><div id="stebesena" class="wp-block-group alignfull vl-monitor">
			<!-- wp:group {"align":"wide","className":"vl-monitor-grid","layout":{"type":"default"}} --><div class="wp-block-group alignwide vl-monitor-grid">
				<!-- wp:group {"className":"vl-monitor-copy","layout":{"type":"default"}} --><div class="wp-block-group vl-monitor-copy">
					<!-- wp:paragraph {"className":"vl-eyebrow"} --><p class="vl-eyebrow">PROJEKTŲ STEBĖSENA / ENLAPS + MYTIKEE MONITOR</p><!-- /wp:paragraph -->
					<!-- wp:heading --><h2 class="wp-block-heading">laikas keičia projektą.<br>vaizdas išsaugo eigą.</h2><!-- /wp:heading -->
					<!-- wp:paragraph --><p>„Tikee“ kameros ir „myTikee Monitor“ gali sujungti projekto archyvą, nuotolinę peržiūrą, dalijimąsi ir privatumo priemones pagal suderintą konfigūraciją.</p><!-- /wp:paragraph -->
					<!-- wp:paragraph {"className":"vl-muted"} --><p class="vl-muted">Dienos ir vakaro kadrų palyginimas yra vietinė demonstracija su pateiktais kadrais.</p><!-- /wp:paragraph -->
					<!-- wp:paragraph --><p><a class="vl-text-link" href="#kontaktai">Aptarti stebėseną ↗</a></p><!-- /wp:paragraph -->
				</div><!-- /wp:group -->
				<!-- wp:videolab/image-comparison {"dayId":%3$d,"eveningId":%2$d,"dayLabel":"DIENA","eveningLabel":"VAKARAS"} /-->
			</div><!-- /wp:group -->
		</div><!-- /wp:group -->

		<!-- wp:group {"anchor":"apie","align":"wide","className":"vl-about","layout":{"type":"default"}} --><div id="apie" class="wp-block-group alignwide vl-about">
			<!-- wp:group {"layout":{"type":"default"}} --><div class="wp-block-group">
				<!-- wp:paragraph {"className":"vl-eyebrow"} --><p class="vl-eyebrow">MAŽA KOMANDA. AIŠKI ATSAKOMYBĖ.</p><!-- /wp:paragraph -->
				<!-- wp:heading --><h2 class="wp-block-heading">vienas kontaktas.<br>bendra kryptis.</h2><!-- /wp:heading -->
			</div><!-- /wp:group -->
			<!-- wp:group {"className":"vl-about-copy","layout":{"type":"default"}} --><div class="wp-block-group vl-about-copy">
				<!-- wp:paragraph --><p>Su jumis nuo pirmo pokalbio iki galutinio rezultato dirba vienas atsakingas partneris. Pagal projekto poreikį pasitelkiami papildomi kūrybos ir gamybos specialistai.</p><!-- /wp:paragraph -->
				<!-- wp:list {"ordered":true,"className":"vl-steps"} --><ol class="wp-block-list vl-steps"><li><span>01</span><div><h3>Suprantame užduotį</h3><p>Tikslas, auditorija, kanalai ir numatoma apimtis.</p></div></li><li><span>02</span><div><h3>Suderiname planą</h3><p>Kūrybinė kryptis, gamyba, terminai ir biudžetas.</p></div></li><li><span>03</span><div><h3>Sukuriame turinį</h3><p>Nuo kadrų atrankos iki paruoštų naudoti formatų.</p></div></li></ol><!-- /wp:list -->
			</div><!-- /wp:group -->
		</div><!-- /wp:group -->

		<!-- wp:group {"anchor":"kontaktai","align":"full","className":"vl-contact","layout":{"type":"constrained"}} --><div id="kontaktai" class="wp-block-group alignfull vl-contact">
			<!-- wp:group {"align":"wide","layout":{"type":"default"}} --><div class="wp-block-group alignwide">
				<!-- wp:paragraph {"className":"vl-eyebrow"} --><p class="vl-eyebrow">KOKIĄ ISTORIJĄ KURSIME?</p><!-- /wp:paragraph -->
				<!-- wp:group {"className":"vl-contact-grid","layout":{"type":"default"}} --><div class="wp-block-group vl-contact-grid">
					<!-- wp:heading --><h2 class="wp-block-heading">aptarkime<br>jūsų projektą.</h2><!-- /wp:heading -->
					<!-- wp:group {"layout":{"type":"default"}} --><div class="wp-block-group">
						<!-- wp:paragraph --><p>Trumpai aprašykite savo projektą ir norimą kryptį.</p><!-- /wp:paragraph -->
						<!-- wp:paragraph {"className":"vl-contact-note"} --><p class="vl-contact-note">Kontaktai ir veikianti pateikimo forma bus įjungti gavus patvirtintą gavėją bei privatumo tekstą. Ši vietinė versija duomenų nesiunčia.</p><!-- /wp:paragraph -->
					</div><!-- /wp:group -->
				</div><!-- /wp:group -->
			</div><!-- /wp:group -->
		</div><!-- /wp:group -->',
		$hero_attrs,
		(int) $media['hero'],
		(int) $media['day']
	);
}

function videolab_content_seed_monitoring_draft() {
	return '<!-- wp:paragraph --><p>Šis vietinis juodraštis yra numatyta išsamios v5 <code>#galimybes</code> sekcijos vieta. Jis nėra susietas iš viešos pradžios navigacijos.</p><!-- /wp:paragraph -->
	<!-- wp:heading --><h2 class="wp-block-heading">matykite eigą.<br>dalinkitės rezultatu.</h2><!-- /wp:heading -->
	<!-- wp:details --><details class="wp-block-details"><summary>01 / Peržiūra iš bet kur</summary><!-- wp:paragraph --><p>Naujausi persiųsti kadrai ir sukaupta projekto istorija pasiekiami naršyklėje. Atnaujinimas priklauso nuo sutarto grafiko ir ryšio; tai nėra nuolatinė tiesioginė transliacija.</p><!-- /wp:paragraph --></details><!-- /wp:details -->
	<!-- wp:details --><details class="wp-block-details"><summary>02 / Pokyčių palyginimas</summary><!-- wp:paragraph --><p>Du laikotarpiai slankikliu, greta arba su vaizdų perdanga gali padėti parodyti projekto pokytį.</p><!-- /wp:paragraph --></details><!-- /wp:details -->
	<!-- wp:details --><details class="wp-block-details"><summary>03 / Timelapse ir komunikacija</summary><!-- wp:paragraph --><p>Debesijoje gali būti kuriamos timelapse sekos. Individualaus montažo apimtis derinama atskirai.</p><!-- /wp:paragraph --></details><!-- /wp:details -->
	<!-- wp:details --><details class="wp-block-details"><summary>04 / Prieiga komandai ir partneriams</summary><!-- wp:paragraph --><p>Apsaugota peržiūra ir viešas rodinys yra skirtingi režimai; konkretūs gavėjai ir viešinimas derinami atskirai.</p><!-- /wp:paragraph --></details><!-- /wp:details -->
	<!-- wp:details --><details class="wp-block-details"><summary>05 / Privatumo priemonės</summary><!-- wp:paragraph --><p>Žmonių suliejimas bei fiksuotų zonų maskavimas turi būti suplanuoti prieš siuntimą. Šios priemonės savaime negarantuoja viso projekto atitikties BDAR.</p><!-- /wp:paragraph --></details><!-- /wp:details -->
	<!-- wp:details --><details class="wp-block-details"><summary>06 / Techninė stebėsena</summary><!-- wp:paragraph --><p>Kameros būklės duomenys atitinka paskutinį jos prisijungimą. Priežiūros ir reagavimo tvarka nustatoma pasiūlyme.</p><!-- /wp:paragraph --></details><!-- /wp:details -->
	<!-- wp:heading --><h2 class="wp-block-heading">privatumas ir papildomos galimybės.</h2><!-- /wp:heading -->
	<!-- wp:paragraph --><p>Originalų bei apdoroto rodinio prieigos ir saugojimas derinami atskirai. Live, AI analizė, kelių kamerų apžvalga ir duomenų perdavimas tikrinami pagal įrangą, planą ir apimtį.</p><!-- /wp:paragraph -->
	<!-- wp:paragraph --><p><strong>myTikee projekto rodinys: išjungtas.</strong> Iframe ar privati nuoroda nebus išvedami be patvirtinto resurso ir viešinimo leidimo.</p><!-- /wp:paragraph -->';
}

function videolab_content_seed_site( $asset_dir ) {
	$definitions = array(
		'logo'    => array( 'logo.png', 'Video Lab' ),
		'icon'    => array( 'icon.png', '' ),
		'hero'    => array( file_exists( $asset_dir . '/hero.webp' ) ? 'hero.webp' : 'hero.jpeg', 'Statomo pramoninio pastato kolonos ir technika saulėlydžio metu' ),
		'day'     => array( file_exists( $asset_dir . '/day.webp' ) ? 'day.webp' : 'day.jpeg', 'Pramoninio pastato statyba dieną' ),
		'lift'    => array( file_exists( $asset_dir . '/lift.webp' ) ? 'lift.webp' : 'lift.jpg', 'Naktinis vamzdyno kėlimas kranu statybvietėje' ),
		'build'   => array( file_exists( $asset_dir . '/build.webp' ) ? 'build.webp' : 'build.jpeg', 'Statybų projekto vaizdas iš pateiktos medžiagos' ),
		'company' => array( file_exists( $asset_dir . '/company.webp' ) ? 'company.webp' : 'company.png', 'AI sugeneruota įmonės turinio koncepcija: specialistai gamybos ceche' ),
		'product' => array( file_exists( $asset_dir . '/product.webp' ) ? 'product.webp' : 'product.png', 'AI sugeneruota produkto koncepcija: metalinė kolonėlė studijoje' ),
	);
	$media = array();
	foreach ( $definitions as $key => $definition ) {
		list( $filename, $alt ) = $definition;
		$id = videolab_content_seed_attachment( $asset_dir, $filename, $alt );
		if ( is_wp_error( $id ) ) {
			return $id;
		}
		$media[ $key ] = $id;
	}

	foreach ( array( 'stebesena' => 'Projektų stebėsena', 'periodinis-turinys' => 'Periodinis turinys', 'produkto-video' => 'Produkto video' ) as $slug => $name ) {
		if ( ! term_exists( $slug, 'work_service' ) ) {
			wp_insert_term( $name, 'work_service', array( 'slug' => $slug ) );
		}
	}

	$services_parent = videolab_content_seed_insert_post(
		'page:services',
		array(
			'post_type'   => 'page',
			'post_status' => 'draft',
			'post_title'  => 'Paslaugos',
			'post_name'   => 'paslaugos',
			'post_content'=> '<!-- wp:paragraph --><p>Paslaugų puslapių tėvinis juodraštis.</p><!-- /wp:paragraph -->',
		)
	);
	if ( is_wp_error( $services_parent ) ) {
		return $services_parent;
	}

	$service_data = array(
		'monitoring' => array(
			'title'       => 'Projektų stebėsena',
			'slug'        => 'projektu-stebesena',
			'excerpt'     => 'Projekto eiga, archyvas ir galutinis filmas.',
			'price'       => 10500,
			'period'      => '/ 12 mėn.',
			'note'        => 'Kamerų skaičius, prieiga, saugojimas ir turinio apimtis – individualiame pasiūlyme.',
			'scope'       => 'Ilgalaikė vizualinė dokumentacija su „Enlaps“ ir „myTikee Monitor“. Projekto pokyčiai tampa medžiaga komunikacijai ir jo istorijai.',
			'exclusions'  => 'Konkreti įrangos, filmavimų ir galutinio turinio apimtis suderinama pasiūlyme. Tai nėra apsaugos ar techninės priežiūros paslauga.',
			'cta'         => 'Plačiau apie stebėseną',
			'content'     => videolab_content_seed_monitoring_draft(),
			'template'    => 'monitoring-service',
		),
		'periodic' => array(
			'title'       => 'Periodinis turinys',
			'slug'        => 'periodinis-turinys',
			'excerpt'     => 'Nuosekli įmonės komunikacija.',
			'price'       => 4200,
			'period'      => '/mėn.',
			'note'        => 'Dažnis, formatai ir bendradarbiavimo laikotarpis nustatomi pagal poreikį.',
			'scope'       => 'Planavimas, periodiniai filmavimai ir turinio adaptavimas jūsų komunikacijos kanalams.',
			'exclusions'  => 'Filmavimų dažnis ir formatų skaičius nustatomi tik suderinus komunikacijos poreikį.',
			'cta'         => 'Aptarti turinio sistemą',
			'content'     => '<!-- wp:paragraph --><p>Paslaugos puslapio turinys bus rengiamas 2 etape.</p><!-- /wp:paragraph -->',
			'template'    => '',
		),
		'product' => array(
			'title'       => 'Produkto video',
			'slug'        => 'produkto-video',
			'excerpt'     => 'Produkto pristatymas ir kampanijos.',
			'price'       => 3000,
			'period'      => '',
			'note'        => 'Galutinė apimtis nustatoma individualiame pasiūlyme.',
			'scope'       => 'Nuo kūrybinės krypties iki produkto filmo ir sutartų jo formatų.',
			'exclusions'  => 'AI, filmavimas, scenografija ir papildomi specialistai derinami pagal užduotį.',
			'cta'         => 'Aptarti produkto video',
			'content'     => '<!-- wp:paragraph --><p>Paslaugos puslapio turinys bus rengiamas 2 etape.</p><!-- /wp:paragraph -->',
			'template'    => '',
		),
	);

	$order = 0;
	foreach ( $service_data as $key => $data ) {
		++$order;
		$page_id = videolab_content_seed_insert_post(
			'service:' . $key,
			array(
				'post_type'    => 'page',
				'post_status'  => 'draft',
				'post_parent'  => $services_parent,
				'post_title'   => $data['title'],
				'post_name'    => $data['slug'],
				'post_excerpt' => $data['excerpt'],
				'post_content' => $data['content'],
				'menu_order'   => $order,
			)
		);
		if ( is_wp_error( $page_id ) ) {
			return $page_id;
		}
		update_post_meta( $page_id, 'videolab_service_key', $key );
		update_post_meta( $page_id, 'videolab_starting_price_eur', $data['price'] );
		update_post_meta( $page_id, 'videolab_price_period', $data['period'] );
		update_post_meta( $page_id, 'videolab_price_note', $data['note'] );
		update_post_meta( $page_id, 'videolab_scope', $data['scope'] );
		update_post_meta( $page_id, 'videolab_exclusions', $data['exclusions'] );
		update_post_meta( $page_id, 'videolab_cta', $data['cta'] );
		update_post_meta( $page_id, 'videolab_viewer_mode', 'none' );
		if ( $data['template'] ) {
			update_post_meta( $page_id, '_wp_page_template', $data['template'] );
		}
	}

	$work_data = array(
		array(
			'key'       => 'work:site',
			'title'     => 'procesas tampa istorija.',
			'slug'      => 'projektu-stebesenos-kadrai',
			'excerpt'   => 'Pateikta statybų projektų medžiaga. Objektų pavadinimai, datos ir atliktų darbų apimtis dar nepatvirtinti.',
			'origin'    => 'real',
			'service'   => 'stebesena',
			'thumbnail' => $media['lift'],
			'gallery'   => array( $media['lift'], $media['hero'], $media['day'], $media['build'] ),
			'content'   => '<!-- wp:heading --><h2 class="wp-block-heading">užduotis.</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Patvirtintas kliento užduoties aprašymas dar nepateiktas. Šiame vietiniame įraše rodoma tik vartotojo pateikta statybų medžiaga.</p><!-- /wp:paragraph --><!-- wp:heading --><h2 class="wp-block-heading">sprendimas.</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Sprendimo apimtis ir konkretaus objekto tapatybė turi būti patvirtinti prieš viešinimą.</p><!-- /wp:paragraph -->',
		),
		array(
			'key'       => 'work:company-concept',
			'title'     => 'žmonės. darbas. įmonė.',
			'slug'      => 'imones-turinio-koncepcija',
			'excerpt'   => 'AI sugeneruota įmonės turinio vizualinė koncepcija, ne kliento projektas.',
			'origin'    => 'ai_concept',
			'service'   => 'periodinis-turinys',
			'thumbnail' => $media['company'],
			'gallery'   => array( $media['company'] ),
			'content'   => '<!-- wp:heading --><h2 class="wp-block-heading">koncepcijos paskirtis.</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Šis AI sukurtas vaizdas rodo galimą periodinio įmonės turinio kryptį. Tai nėra įgyvendintas kliento darbas, rezultatas ar atsiliepimas.</p><!-- /wp:paragraph -->',
		),
		array(
			'key'       => 'work:product-concept',
			'title'     => 'detalės, kurios išskiria.',
			'slug'      => 'produkto-video-koncepcija',
			'excerpt'   => 'AI sugeneruota produkto vizualinė koncepcija, ne kliento projektas.',
			'origin'    => 'ai_concept',
			'service'   => 'produkto-video',
			'thumbnail' => $media['product'],
			'gallery'   => array( $media['product'] ),
			'content'   => '<!-- wp:heading --><h2 class="wp-block-heading">koncepcijos paskirtis.</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Šis AI sukurtas vaizdas rodo galimą produkto pristatymo kryptį. Tai nėra įgyvendintas kliento darbas, rezultatas ar atsiliepimas.</p><!-- /wp:paragraph -->',
		),
	);

	foreach ( $work_data as $index => $work ) {
		$content = $work['content'] . videolab_content_seed_gallery_block( $work['gallery'] );
		$work_id = videolab_content_seed_insert_post(
			$work['key'],
			array(
				'post_type'    => 'work',
				'post_status'  => 'publish',
				'post_title'   => $work['title'],
				'post_name'    => $work['slug'],
				'post_excerpt' => $work['excerpt'],
				'post_content' => $content,
				'menu_order'   => $index + 1,
			)
		);
		if ( is_wp_error( $work_id ) ) {
			return $work_id;
		}
		set_post_thumbnail( $work_id, $work['thumbnail'] );
		wp_set_object_terms( $work_id, $work['service'], 'work_service' );
		update_post_meta( $work_id, 'videolab_origin', $work['origin'] );
		update_post_meta( $work_id, 'videolab_gallery_ids', $work['gallery'] );
	}

	$home_id = videolab_content_seed_insert_post(
		'page:home',
		array(
			'post_type'    => 'page',
			'post_status'  => 'publish',
			'post_title'   => 'Pradžia',
			'post_name'    => 'pradzia',
			'post_excerpt' => 'Vizualinio turinio sistemos projektams, įmonėms ir produktams.',
			'post_content' => videolab_content_seed_home_content( $media ),
		)
	);
	if ( is_wp_error( $home_id ) ) {
		return $home_id;
	}

	set_theme_mod( 'custom_logo', $media['logo'] );
	update_option( 'blogname', 'Video Lab' );
	update_option( 'blogdescription', 'Vizualinio turinio partneris' );
	update_option( 'timezone_string', 'Europe/Vilnius' );
	update_option( 'blog_public', 0 );
	update_option( 'show_on_front', 'page' );
	update_option( 'page_on_front', $home_id );
	update_option( 'page_for_posts', 0 );
	update_option( 'permalink_structure', '/%postname%/' );
	flush_rewrite_rules();

	return true;
}

/**
 * Applies narrowly scoped fixes to existing seeded content.
 *
 * Exact-value checks preserve any later editor changes. The homepage update
 * only removes or replaces known starter copy and adds the missing Cover alt
 * attribute required by Gutenberg's block validator.
 */
function videolab_content_apply_content_migration_0_1_1() {
	if ( version_compare( (string) get_option( 'videolab_content_migration_version', '0.0.0' ), '0.1.1', '>=' ) ) {
		return;
	}

	$monitoring_id = videolab_content_seed_find_post( 'service:monitoring', 'page' );
	if ( $monitoring_id && 'Aptarti stebėseną' === get_post_meta( $monitoring_id, 'videolab_cta', true ) ) {
		update_post_meta( $monitoring_id, 'videolab_cta', 'Plačiau apie stebėseną' );
	}

	$home_id = videolab_content_seed_find_post( 'page:home', 'page' );
	if ( $home_id ) {
		$content = (string) get_post_field( 'post_content', $home_id );
		$updated = str_replace(
			array(
				'<!-- wp:paragraph {"className":"vl-monitor-status"} --><p class="vl-monitor-status"><strong>myTikee rodinys išjungtas.</strong> Faktinė integracija bus jungiama tik gavus patvirtintą viešinimui tinkamą resursą.</p><!-- /wp:paragraph -->',
				'<p>Pasirinkite kryptį ir pasiruoškite trumpai aprašyti poreikį.</p>',
			),
			array(
				'',
				'<p>Trumpai aprašykite savo projektą ir norimą kryptį.</p>',
			),
			$content
		);

		$updated = preg_replace_callback(
			'~<!-- wp:cover (\{[^\n]*\}) -->~',
			static function ( $matches ) {
				$attributes = json_decode( $matches[1], true );
				if (
					! is_array( $attributes )
					|| false === strpos( (string) ( $attributes['className'] ?? '' ), 'vl-hero' )
					|| empty( $attributes['id'] )
				) {
					return $matches[0];
				}

				$alt = get_post_meta( (int) $attributes['id'], '_wp_attachment_image_alt', true );
				if ( '' === $alt || ( $attributes['alt'] ?? '' ) === $alt ) {
					return $matches[0];
				}

				$attributes['alt'] = $alt;
				return '<!-- wp:cover ' . wp_json_encode( $attributes, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . ' -->';
			},
			$updated,
			1
		);

		if ( is_string( $updated ) && $updated !== $content ) {
			wp_update_post(
				wp_slash(
					array(
						'ID'           => $home_id,
						'post_content' => $updated,
					)
				)
			);
		}
	}

	$work_titles = array(
		'work:site'            => array( 'Procesas tampa istorija.', 'procesas tampa istorija.' ),
		'work:company-concept' => array( 'Žmonės. Darbas. Įmonė.', 'žmonės. darbas. įmonė.' ),
		'work:product-concept' => array( 'Detalės, kurios išskiria.', 'detalės, kurios išskiria.' ),
	);
	foreach ( $work_titles as $key => $titles ) {
		$work_id = videolab_content_seed_find_post( $key, 'work' );
		if ( $work_id && $titles[0] === get_the_title( $work_id ) ) {
			wp_update_post(
				array(
					'ID'         => $work_id,
					'post_title' => $titles[1],
				)
			);
		}
	}

	update_option( 'videolab_content_migration_version', '0.1.1', false );
}
add_action( 'init', 'videolab_content_apply_content_migration_0_1_1', 100 );

/**
 * Removes service defaults accidentally saved on ordinary pages by 0.1.1.
 */
function videolab_content_apply_content_migration_0_1_2() {
	if ( version_compare( (string) get_option( 'videolab_content_migration_version', '0.0.0' ), '0.1.2', '>=' ) ) {
		return;
	}

	$page_ids = get_posts(
		array(
			'post_type'      => 'page',
			'post_status'    => 'any',
			'posts_per_page' => -1,
			'meta_key'       => 'videolab_service_key',
			'fields'         => 'ids',
		)
	);
	$valid_keys = array( 'monitoring', 'periodic', 'product' );
	$meta_keys  = array(
		'videolab_service_key',
		'videolab_starting_price_eur',
		'videolab_price_period',
		'videolab_price_note',
		'videolab_scope',
		'videolab_exclusions',
		'videolab_cta',
		'videolab_viewer_mode',
	);

	foreach ( $page_ids as $page_id ) {
		if ( in_array( get_post_meta( $page_id, 'videolab_service_key', true ), $valid_keys, true ) ) {
			continue;
		}
		foreach ( $meta_keys as $meta_key ) {
			delete_post_meta( $page_id, $meta_key );
		}
	}

	update_option( 'videolab_content_migration_version', '0.1.2', false );
}
add_action( 'init', 'videolab_content_apply_content_migration_0_1_2', 101 );

/**
 * Stores the work-grid footnote as a block attribute so editors can change it.
 * Only replaces the original self-closing block comment.
 */
function videolab_content_apply_content_migration_0_1_5() {
	if ( version_compare( (string) get_option( 'videolab_content_migration_version', '0.0.0' ), '0.1.5', '>=' ) ) {
		return;
	}

	$needle  = '<!-- wp:videolab/work-grid /-->';
	$replace = '<!-- wp:videolab/work-grid ' . wp_json_encode(
		array(
			'note' => videolab_content_default_work_note(),
		),
		JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
	) . ' /-->';

	$pages = get_posts(
		array(
			'post_type'      => array( 'page', 'post', 'work' ),
			'post_status'    => 'any',
			'posts_per_page' => -1,
		)
	);

	foreach ( $pages as $page ) {
		if ( false === strpos( $page->post_content, $needle ) ) {
			continue;
		}
		wp_update_post(
			array(
				'ID'           => $page->ID,
				'post_content' => str_replace( $needle, $replace, $page->post_content ),
			)
		);
	}

	update_option( 'videolab_content_migration_version', '0.1.5', false );
}
add_action( 'init', 'videolab_content_apply_content_migration_0_1_5', 102 );

function videolab_content_is_vl_hero_cover( $block ) {
	if ( ( $block['blockName'] ?? '' ) !== 'core/cover' ) {
		return false;
	}

	return false !== strpos( (string) ( $block['attrs']['className'] ?? '' ), 'vl-hero' );
}

function videolab_content_extract_hero_from_cover( $block ) {
	$attrs = is_array( $block['attrs'] ?? null ) ? $block['attrs'] : array();
	$data  = array(
		'align'   => 'full',
		'imageId' => 0,
		'videoId' => 0,
		'alt'     => sanitize_text_field( (string) ( $attrs['alt'] ?? '' ) ),
		'ctaText' => videolab_content_default_hero_cta(),
		'ctaUrl'  => '#stebesena',
		'label'   => '01 / PROJEKTŲ STEBĖSENA',
	);

	$media_id = absint( $attrs['id'] ?? 0 );
	if ( ( $attrs['backgroundType'] ?? '' ) === 'video' ) {
		$data['videoId'] = $media_id;
	} else {
		$data['imageId'] = $media_id;
	}

	$walk = function ( $blocks ) use ( &$data, &$walk ) {
		foreach ( $blocks as $inner ) {
			$name  = $inner['blockName'] ?? '';
			$class = (string) ( $inner['attrs']['className'] ?? '' );
			$html  = (string) ( $inner['innerHTML'] ?? '' );

			if ( 'core/button' === $name ) {
				if ( ! empty( $inner['attrs']['url'] ) ) {
					$data['ctaUrl'] = (string) $inner['attrs']['url'];
				} elseif ( preg_match( '/href="([^"]*)"/', $html, $match ) ) {
					$data['ctaUrl'] = $match[1];
				}

				$text = trim( preg_replace( '/\s*↗\s*/u', '', wp_strip_all_tags( $html ) ) );
				if ( '' !== $text ) {
					$starter = array(
						'Nuo proceso iki rezultato',
						'nuo proceso iki rezultato',
					);
					$data['ctaText'] = in_array( $text, $starter, true )
						? videolab_content_default_hero_cta()
						: $text;
				}
			}

			if ( 'core/paragraph' === $name && false !== strpos( $class, 'vl-hero-label' ) ) {
				$label = trim( wp_strip_all_tags( $html ) );
				if ( '' !== $label ) {
					$data['label'] = $label;
				}
			}

			if ( ! empty( $inner['innerBlocks'] ) ) {
				$walk( $inner['innerBlocks'] );
			}
		}
	};
	$walk( $block['innerBlocks'] ?? array() );

	return $data;
}

function videolab_content_replace_hero_cover_blocks( &$blocks ) {
	$changed = false;

	foreach ( $blocks as &$block ) {
		if ( videolab_content_is_vl_hero_cover( $block ) ) {
			$block   = array(
				'blockName'    => 'videolab/hero-media',
				'attrs'        => videolab_content_extract_hero_from_cover( $block ),
				'innerBlocks'  => array(),
				'innerHTML'    => '',
				'innerContent' => array(),
			);
			$changed = true;
			continue;
		}

		if ( ! empty( $block['innerBlocks'] ) ) {
			$changed = videolab_content_replace_hero_cover_blocks( $block['innerBlocks'] ) || $changed;
		}
	}
	unset( $block );

	return $changed;
}

/**
 * Moves the homepage hero off Cover so the CTA can sit below the media on
 * small screens. Preserves the existing image, link, and label.
 */
function videolab_content_apply_content_migration_0_1_8() {
	if ( version_compare( (string) get_option( 'videolab_content_migration_version', '0.0.0' ), '0.1.8', '>=' ) ) {
		return;
	}

	$pages = get_posts(
		array(
			'post_type'      => array( 'page', 'post', 'work' ),
			'post_status'    => 'any',
			'posts_per_page' => -1,
		)
	);

	foreach ( $pages as $page ) {
		$content = (string) $page->post_content;
		if ( false !== strpos( $content, 'wp:videolab/hero-media' ) || false === strpos( $content, 'vl-hero' ) ) {
			continue;
		}

		$blocks = parse_blocks( $content );
		if ( ! videolab_content_replace_hero_cover_blocks( $blocks ) ) {
			continue;
		}

		wp_update_post(
			array(
				'ID'           => $page->ID,
				'post_content' => serialize_blocks( $blocks ),
			)
		);
	}

	update_option( 'videolab_content_migration_version', '0.1.8', false );
}
add_action( 'init', 'videolab_content_apply_content_migration_0_1_8', 103 );

/**
 * Updates known starter hero CTA casing and adds focal-point defaults.
 * Does not rewrite unrelated homepage copy.
 */
function videolab_content_apply_content_migration_0_1_9() {
	if ( version_compare( (string) get_option( 'videolab_content_migration_version', '0.0.0' ), '0.1.9', '>=' ) ) {
		return;
	}

	$pages = get_posts(
		array(
			'post_type'      => array( 'page', 'post', 'work' ),
			'post_status'    => 'any',
			'posts_per_page' => -1,
		)
	);

	foreach ( $pages as $page ) {
		$content = (string) $page->post_content;
		if ( false === strpos( $content, 'wp:videolab/hero-media' ) ) {
			continue;
		}

		$updated = preg_replace_callback(
			'/<!-- wp:videolab\/hero-media\s+(\{.*?\})\s+\/-->/',
			static function ( $matches ) {
				$attrs = json_decode( $matches[1], true );
				if ( ! is_array( $attrs ) ) {
					return $matches[0];
				}

				$cta   = trim( (string) ( $attrs['ctaText'] ?? '' ) );
				$known = array( 'nuo proceso iki rezultato', 'Nuo proceso iki rezultato' );
				if ( '' === $cta || in_array( $cta, $known, true ) ) {
					$attrs['ctaText'] = videolab_content_default_hero_cta();
				}
				if ( empty( $attrs['focalPoint'] ) || ! is_array( $attrs['focalPoint'] ) ) {
					$attrs['focalPoint'] = array(
						'x' => 0.56,
						'y' => 0.67,
					);
				}
				if ( ! isset( $attrs['mobileVideoId'] ) ) {
					$attrs['mobileVideoId'] = 0;
				}

				return '<!-- wp:videolab/hero-media ' . wp_json_encode( $attrs, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . ' /-->';
			},
			$content
		);

		if ( is_string( $updated ) && $updated !== $content ) {
			wp_update_post(
				array(
					'ID'           => $page->ID,
					'post_content' => $updated,
				)
			);
		}
	}

	update_option( 'videolab_content_migration_version', '0.1.9', false );
}
add_action( 'init', 'videolab_content_apply_content_migration_0_1_9', 104 );
